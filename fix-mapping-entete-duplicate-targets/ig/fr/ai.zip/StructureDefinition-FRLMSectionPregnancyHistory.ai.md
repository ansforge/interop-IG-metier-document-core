# Logical model - FR LM Pregnancy History - FR Document Core (Modèle métier) v0.1.0

## Modèle logique: Logical model - FR LM Pregnancy History 

 
Section Historique des grossesses 

**Utilisations:**

* Utilise ce/t/te Modèle logique: [Logical model - FR LM Corps document](StructureDefinition-FRLMCorpsDocument.md)

Vous pouvez également vérifier [les usages dans le FHIR IG Statistics](https://packages2.fhir.org/xig/ans.fr.document-core|current/StructureDefinition/FRLMSectionPregnancyHistory)

### Vues formelles du contenu du profil

 [Description des profils, des différentiels, des instantanés et de leurs représentations](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Tableau différentiel (differential)](#tabs-diff) 
*  [Tableau récapitulatif (snapshot)](#tabs-snap) 
*  [Statistiques/Références](#tabs-summ) 
*  [Tous](#tabs-all) 

Cette structure est dérivée de [FRLMSection](StructureDefinition-FRLMSection.md) 

Cette structure est dérivée de [FRLMSection](StructureDefinition-FRLMSection.md) 

** Résumé **

Obligatoire : 1 élément
 Interdit : 1 élément

 **Vue différentielle** 

Cette structure est dérivée de [FRLMSection](StructureDefinition-FRLMSection.md) 

 **Vue d'ensembleView** 

Cette structure est dérivée de [FRLMSection](StructureDefinition-FRLMSection.md) 

** Résumé **

Obligatoire : 1 élément
 Interdit : 1 élément

 

Autres représentations du profil : [CSV](../StructureDefinition-FRLMSectionPregnancyHistory.csv), [Excel](../StructureDefinition-FRLMSectionPregnancyHistory.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "FRLMSectionPregnancyHistory",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-type-characteristics",
    "valueCode" : "can-be-target"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-type-characteristics",
    "valueCode" : "can-be-target"
  }],
  "url" : "https://interop.esante.gouv.fr/ig/document-core/StructureDefinition/FRLMSectionPregnancyHistory",
  "version" : "0.1.0",
  "name" : "FRLMSectionPregnancyHistory",
  "title" : "Logical model  - FR LM Pregnancy History",
  "status" : "draft",
  "date" : "2026-09-03T10:02:14+00:00",
  "publisher" : "Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris",
  "contact" : [{
    "name" : "Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris",
    "telecom" : [{
      "system" : "url",
      "value" : "https://esante.gouv.fr"
    }]
  }],
  "description" : "Section Historique des grossesses",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "FR",
      "display" : "France (la)"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "kind" : "logical",
  "abstract" : false,
  "type" : "https://interop.esante.gouv.fr/ig/document-core/StructureDefinition/FRLMSectionPregnancyHistory",
  "baseDefinition" : "https://interop.esante.gouv.fr/ig/document-core/StructureDefinition/FRLMSection|0.1.0",
  "derivation" : "specialization",
  "differential" : {
    "element" : [{
      "id" : "FRLMSectionPregnancyHistory",
      "path" : "FRLMSectionPregnancyHistory",
      "short" : "Logical model  - FR LM Pregnancy History",
      "definition" : "Section Historique des grossesses"
    },
    {
      "id" : "FRLMSectionPregnancyHistory.titleSection",
      "path" : "FRLMSectionPregnancyHistory.titleSection",
      "min" : 1
    },
    {
      "id" : "FRLMSectionPregnancyHistory.subSection",
      "path" : "FRLMSectionPregnancyHistory.subSection",
      "max" : "0"
    },
    {
      "id" : "FRLMSectionPregnancyHistory.entry.pregnancyStatus",
      "path" : "FRLMSectionPregnancyHistory.entry.pregnancyStatus",
      "short" : "Statut de grossesse",
      "definition" : "Statut de grossesse",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "https://interop.esante.gouv.fr/ig/document-core/StructureDefinition/FRLMPregnancyStatus"
      }]
    },
    {
      "id" : "FRLMSectionPregnancyHistory.entry.pregnancyHistory",
      "path" : "FRLMSectionPregnancyHistory.entry.pregnancyHistory",
      "short" : "Historique des grossesses. Exemple : nb d'enfants nés vivants, etc…",
      "definition" : "Historique des grossesses. Exemple : nb d'enfants nés vivants, etc…",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "https://interop.esante.gouv.fr/ig/document-core/StructureDefinition/FRLMPregnancyHistory"
      }]
    },
    {
      "id" : "FRLMSectionPregnancyHistory.note",
      "path" : "FRLMSectionPregnancyHistory.note",
      "short" : "Commentaire",
      "definition" : "Commentaire",
      "min" : 0,
      "max" : "1",
      "type" : [{
        "code" : "string"
      }]
    }]
  }
}

```
