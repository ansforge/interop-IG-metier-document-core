# Logical model - FR LM Advance Directives - FR Document Core (Modèle métier) v0.1.0

## Modèle logique: Logical model - FR LM Advance Directives 

 
Section Directives anticipées 

**Utilisations:**

* Utilise ce/t/te Modèle logique: [Logical model - FR LM Corps document](StructureDefinition-FRLMCorpsDocument.md)

Vous pouvez également vérifier [les usages dans le FHIR IG Statistics](https://packages2.fhir.org/xig/ans.fr.metier.document.core|current/StructureDefinition/FRLMAdvanceDirectives)

### Vues formelles du contenu du profil

 [Description des profils, des différentiels, des instantanés et de leurs représentations](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

*  [Tableau différentiel (differential)](#tabs-diff) 
*  [Tableau récapitulatif (snapshot)](#tabs-snap) 
*  [Statistiques/Références](#tabs-summ) 
*  [Tous](#tabs-all) 

Cette structure est dérivée de [FRLMSection](StructureDefinition-FRLMSection.md) 

Cette structure est dérivée de [FRLMSection](StructureDefinition-FRLMSection.md) 

** Résumé **

Obligatoire : 1 élément
 Interdit : 1 élément

 **Vue différentielle** 

Cette structure est dérivée de [FRLMSection](StructureDefinition-FRLMSection.md) 

 **Vue d'ensembleView** 

Cette structure est dérivée de [FRLMSection](StructureDefinition-FRLMSection.md) 

** Résumé **

Obligatoire : 1 élément
 Interdit : 1 élément

 

Autres représentations du profil : [CSV](../StructureDefinition-FRLMAdvanceDirectives.csv), [Excel](../StructureDefinition-FRLMAdvanceDirectives.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "FRLMAdvanceDirectives",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-type-characteristics",
    "valueCode" : "can-be-target"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-type-characteristics",
    "valueCode" : "can-be-target"
  }],
  "url" : "https://interop.esante.gouv.fr/ig/metier/document-core/StructureDefinition/FRLMAdvanceDirectives",
  "version" : "0.1.0",
  "name" : "FRLMAdvanceDirectives",
  "title" : "Logical model - FR LM Advance Directives",
  "status" : "draft",
  "date" : "2026-09-07T10:25:17+00:00",
  "publisher" : "Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris",
  "contact" : [{
    "name" : "Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris",
    "telecom" : [{
      "system" : "url",
      "value" : "https://esante.gouv.fr"
    }]
  }],
  "description" : "Section Directives anticipées",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "FR",
      "display" : "France (la)"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "kind" : "logical",
  "abstract" : false,
  "type" : "https://interop.esante.gouv.fr/ig/metier/document-core/StructureDefinition/FRLMAdvanceDirectives",
  "baseDefinition" : "https://interop.esante.gouv.fr/ig/metier/document-core/StructureDefinition/FRLMSection|0.1.0",
  "derivation" : "specialization",
  "differential" : {
    "element" : [{
      "id" : "FRLMAdvanceDirectives",
      "path" : "FRLMAdvanceDirectives",
      "short" : "Logical model - FR LM Advance Directives",
      "definition" : "Section Directives anticipées"
    },
    {
      "id" : "FRLMAdvanceDirectives.titleSection",
      "path" : "FRLMAdvanceDirectives.titleSection",
      "min" : 1
    },
    {
      "id" : "FRLMAdvanceDirectives.subSection",
      "path" : "FRLMAdvanceDirectives.subSection",
      "max" : "0"
    },
    {
      "id" : "FRLMAdvanceDirectives.entry.advanceDirective",
      "path" : "FRLMAdvanceDirectives.entry.advanceDirective",
      "short" : "Entrée Directive anticipée",
      "definition" : "Entrée Directive anticipée",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "https://interop.esante.gouv.fr/ig/metier/document-core/StructureDefinition/FRLMAdvanceDirective"
      }]
    }]
  }
}

```
