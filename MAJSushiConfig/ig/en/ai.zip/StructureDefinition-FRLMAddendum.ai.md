# Logical model - FR LM Addendum - FR Document Core (Modèle métier) v0.1.0

## Logical Model: Logical model - FR LM Addendum 

 
Section Addendum 

**Usages:**

* Use this Logical Model: [Logical model - FR LM Corps document](StructureDefinition-FRLMCorpsDocument.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/ans.fr.document-core|current/StructureDefinition/StructureDefinition-FRLMAddendum.json)

### Formal Views of Profile Content

 [Description Differentials, Snapshots, and other representations](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](../StructureDefinition-FRLMAddendum.csv), [Excel](../StructureDefinition-FRLMAddendum.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "FRLMAddendum",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-type-characteristics",
    "valueCode" : "can-be-target"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-type-characteristics",
    "valueCode" : "can-be-target"
  }],
  "url" : "https://interop.esante.gouv.fr/ig/document-core/StructureDefinition/FRLMAddendum",
  "version" : "0.1.0",
  "name" : "FRLMAddendum",
  "title" : "Logical model - FR LM Addendum",
  "status" : "draft",
  "date" : "2026-09-07T11:40:31+00:00",
  "publisher" : "Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris",
  "contact" : [{
    "name" : "Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris",
    "telecom" : [{
      "system" : "url",
      "value" : "https://esante.gouv.fr"
    }]
  }],
  "description" : "Section Addendum",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "FR",
      "display" : "France (la)"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "kind" : "logical",
  "abstract" : false,
  "type" : "https://interop.esante.gouv.fr/ig/document-core/StructureDefinition/FRLMAddendum",
  "baseDefinition" : "https://interop.esante.gouv.fr/ig/document-core/StructureDefinition/FRLMSection|0.1.0",
  "derivation" : "specialization",
  "differential" : {
    "element" : [{
      "id" : "FRLMAddendum",
      "path" : "FRLMAddendum",
      "short" : "Logical model - FR LM Addendum",
      "definition" : "Section Addendum"
    },
    {
      "id" : "FRLMAddendum.titleSection",
      "path" : "FRLMAddendum.titleSection",
      "min" : 1
    },
    {
      "id" : "FRLMAddendum.subSection",
      "path" : "FRLMAddendum.subSection",
      "max" : "0"
    },
    {
      "id" : "FRLMAddendum.entry",
      "path" : "FRLMAddendum.entry",
      "max" : "0"
    }]
  }
}

```
