# Artifacts Summary - FR Document Core (Modèle métier) v0.1.0

## Artifacts Summary

 
There is no translation page available for the current page, so it has been rendered in the default language 

