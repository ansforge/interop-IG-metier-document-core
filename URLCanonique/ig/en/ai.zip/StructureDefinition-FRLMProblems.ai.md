# Logical model - FR LM Problems - FR Document Core (Modèle métier) v0.1.0

## Logical Model: Logical model - FR LM Problems 

 
Section Problems 

**Usages:**

* Use this Logical Model: [Logical model - FR LM Corps document](StructureDefinition-FRLMCorpsDocument.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/ans.fr.document-core|current/StructureDefinition/StructureDefinition-FRLMProblems.json)

### Formal Views of Profile Content

 [Description Differentials, Snapshots, and other representations](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](../StructureDefinition-FRLMProblems.csv), [Excel](../StructureDefinition-FRLMProblems.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "FRLMProblems",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-type-characteristics",
    "valueCode" : "can-be-target"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-type-characteristics",
    "valueCode" : "can-be-target"
  }],
  "url" : "https://interop.esante.gouv.fr/ig/document-core/StructureDefinition/FRLMProblems",
  "version" : "0.1.0",
  "name" : "FRLMProblems",
  "title" : "Logical model - FR LM Problems",
  "status" : "draft",
  "date" : "2026-09-30T08:39:54+00:00",
  "publisher" : "Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris",
  "contact" : [{
    "name" : "Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris",
    "telecom" : [{
      "system" : "url",
      "value" : "https://esante.gouv.fr"
    }]
  }],
  "description" : "Section Problems",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "FR",
      "display" : "France (la)"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "kind" : "logical",
  "abstract" : false,
  "type" : "https://interop.esante.gouv.fr/ig/document-core/StructureDefinition/FRLMProblems",
  "baseDefinition" : "https://interop.esante.gouv.fr/ig/document-core/StructureDefinition/FRLMSection|0.1.0",
  "derivation" : "specialization",
  "differential" : {
    "element" : [{
      "id" : "FRLMProblems",
      "path" : "FRLMProblems",
      "short" : "Logical model - FR LM Problems",
      "definition" : "Section Problems"
    },
    {
      "id" : "FRLMProblems.titleSection",
      "path" : "FRLMProblems.titleSection",
      "min" : 1
    },
    {
      "id" : "FRLMProblems.subSection",
      "path" : "FRLMProblems.subSection",
      "max" : "0"
    },
    {
      "id" : "FRLMProblems.entry.problem",
      "path" : "FRLMProblems.entry.problem",
      "short" : "Problème",
      "definition" : "Problème",
      "min" : 1,
      "max" : "*",
      "type" : [{
        "code" : "https://interop.esante.gouv.fr/ig/document-core/StructureDefinition/FRLMCondition"
      }]
    }]
  }
}

```
