# Logical model - FR LM Informant - FR Document Core (Modèle métier) v0.1.0

## Logical Model: Logical model - FR LM Informant 

 
Informant (personne ayant fourni des informations utiles à la production du document : professionnel, structure, patient/usager, autre), personne de confiance, personne à prévenir en cas d'urgence, aidant, aidé. 

**Usages:**

* Use this Logical Model: [Logical model - FR LM Entry](StructureDefinition-FRLMEntry.md), [Logical model - FR LM Header Document](StructureDefinition-FRLMHeaderDocument.md) and [Logical model - FR LM Section](StructureDefinition-FRLMSection.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/ans.fr.document-core|current/StructureDefinition/StructureDefinition-FRLMInformant.json)

### Formal Views of Profile Content

 [Description Differentials, Snapshots, and other representations](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](../StructureDefinition-FRLMInformant.csv), [Excel](../StructureDefinition-FRLMInformant.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "FRLMInformant",
  "url" : "https://interop.esante.gouv.fr/ig/document-core/StructureDefinition/FRLMInformant",
  "version" : "0.1.0",
  "name" : "FRLMInformant",
  "title" : "Logical model - FR LM Informant",
  "status" : "draft",
  "date" : "2026-09-30T08:56:57+00:00",
  "publisher" : "Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris",
  "contact" : [{
    "name" : "Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris",
    "telecom" : [{
      "system" : "url",
      "value" : "https://esante.gouv.fr"
    }]
  }],
  "description" : "Informant (personne ayant fourni des informations utiles à la production du document : professionnel, structure, patient/usager, autre), personne de confiance, personne à prévenir en cas d'urgence, aidant, aidé.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "FR",
      "display" : "France (la)"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "kind" : "logical",
  "abstract" : false,
  "type" : "https://interop.esante.gouv.fr/ig/document-core/StructureDefinition/FRLMInformant",
  "baseDefinition" : "http://hl7.org/fhir/StructureDefinition/Base|4.0.1",
  "derivation" : "specialization",
  "differential" : {
    "element" : [{
      "id" : "FRLMInformant",
      "path" : "FRLMInformant",
      "short" : "Logical model - FR LM Informant",
      "definition" : "Informant (personne ayant fourni des informations utiles à la production du document : professionnel, structure, patient/usager, autre), personne de confiance, personne à prévenir en cas d'urgence, aidant, aidé."
    },
    {
      "id" : "FRLMInformant.informant[x]",
      "path" : "FRLMInformant.informant[x]",
      "short" : "Informateur / personne de confiance / personne à prévenir en cas d’urgence / aidant / personne aidée.",
      "definition" : "Informateur / personne de confiance / personne à prévenir en cas d’urgence / aidant / personne aidée.",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "Base"
      }]
    },
    {
      "id" : "FRLMInformant.informant[x].informantProfessional",
      "path" : "FRLMInformant.informant[x].informantProfessional",
      "short" : "L'informateur est un professionnel de santé",
      "definition" : "L'informateur est un professionnel de santé",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "https://interop.esante.gouv.fr/ig/document-core/StructureDefinition/FRLMHealthProfessional"
      }]
    },
    {
      "id" : "FRLMInformant.informant[x].informantOrganisation",
      "path" : "FRLMInformant.informant[x].informantOrganisation",
      "short" : "L'informateur est une organisation",
      "definition" : "L'informateur est une organisation",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "https://interop.esante.gouv.fr/ig/document-core/StructureDefinition/FRLMOrganisation"
      }]
    },
    {
      "id" : "FRLMInformant.informant[x].informantPersonne[x]",
      "path" : "FRLMInformant.informant[x].informantPersonne[x]",
      "short" : "L'informateur est un patient/usager ou un autre type d'informateur (ex : aidant, personne à prévenir en cas d'urgence, etc.)",
      "definition" : "L'informateur est un patient/usager ou un autre type d'informateur (ex : aidant, personne à prévenir en cas d'urgence, etc.)",
      "min" : 0,
      "max" : "*",
      "type" : [{
        "code" : "https://interop.esante.gouv.fr/ig/document-core/StructureDefinition/FRLMRelatedPerson"
      },
      {
        "code" : "https://interop.esante.gouv.fr/ig/document-core/StructureDefinition/FRLMPatient"
      }]
    }]
  }
}

```
