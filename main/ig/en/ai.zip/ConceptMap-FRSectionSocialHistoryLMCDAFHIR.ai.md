# Mapping FRLMSocialHistory → FRCDAHabitusModeDeVieSection / FRLMSocialHistory → FRCompositionDocument.section:sectionSocialHistory - FR Document Core (Modèle métier) v0.1.0

## ConceptMap: Mapping FRLMSocialHistory → FRCDAHabitusModeDeVieSection / FRLMSocialHistory → FRCompositionDocument.section:sectionSocialHistory 

 
Mapping des éléments du modèle métier FRLMSocialHistory vers la section CDA FRCDAHabitusModeDeVieSection, puis vers le profil FHIR FRCompositionDocument.section:sectionSocialHistory. 



## Resource Content

```json
{
  "resourceType" : "ConceptMap",
  "id" : "FRSectionSocialHistoryLMCDAFHIR",
  "url" : "https://interop.esante.gouv.fr/ig/document-core/ConceptMap/FRSectionSocialHistoryLMCDAFHIR",
  "version" : "0.1.0",
  "title" : "Mapping Métier/CDA/FHIR : Habitus et modes de vie",
  "status" : "draft",
  "date" : "2026-08-14T12:00:06+00:00",
  "publisher" : "Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris",
  "contact" : [{
    "name" : "Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris",
    "telecom" : [{
      "system" : "url",
      "value" : "https://esante.gouv.fr"
    }]
  }],
  "description" : "Mapping des éléments du modèle métier FRLMSocialHistory vers la section CDA FRCDAHabitusModeDeVieSection, puis vers le profil FHIR FRCompositionDocument.section:sectionSocialHistory.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "FR",
      "display" : "France (la)"
    }]
  }],
  "group" : [{
    "source" : "https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-lm-social-history",
    "target" : "https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-cda-habitus-mode-de-vie-section",
    "element" : [{
      "code" : "FRLMSocialHistory",
      "target" : [{
        "code" : "FRCDAHabitusModeDeVieSection",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "FRLMSocialHistory.codeSection",
      "target" : [{
        "code" : "FRCDAHabitusModeDeVieSection.code",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "FRLMSocialHistory.titleSection",
      "target" : [{
        "code" : "FRCDAHabitusModeDeVieSection.title",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "FRLMSocialHistory.description",
      "target" : [{
        "code" : "FRCDAHabitusModeDeVieSection.text",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "FRLMSocialHistory.entry.observationSocialHistory:FRLMObservationSocialHistory",
      "target" : [{
        "code" : "FRCDAHabitusModeDeVieSection.entry:FRCDAHabitusModeDeVie",
        "equivalence" : "equivalent"
      }]
    }]
  },
  {
    "source" : "https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-lm-social-history",
    "target" : "https://interop.esante.gouv.fr/ig/document/core/StructureDefinition/fr-composition-document",
    "element" : [{
      "code" : "FRLMSocialHistory",
      "target" : [{
        "code" : "FRCompositionDocument.section:sectionSocialHistory",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "FRLMSocialHistory.codeSection",
      "target" : [{
        "code" : "FRCompositionDocument.section:sectionSocialHistory.code",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "FRLMSocialHistory.titleSection",
      "target" : [{
        "code" : "FRCompositionDocument.section:sectionSocialHistory.title",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "FRLMSocialHistory.description",
      "target" : [{
        "code" : "FRCompositionDocument.section:sectionSocialHistory.text",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "FRLMSocialHistory.entry.observationSocialHistory:FRLMObservationSocialHistory",
      "target" : [{
        "code" : "FRCompositionDocument.section:sectionSocialHistory.entry:FRObservationSocialHistoryDocument",
        "equivalence" : "equivalent"
      }]
    }]
  }]
}

```
