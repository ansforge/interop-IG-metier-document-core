# Introduction - FR Document Core (Modèle métier) v0.1.0

## Introduction

 
There is no translation page available for the current page, so it has been rendered in the default language 

### Introduction technique

Cette section présente les spécifications techniques du guide d'implémentation.

