# ans.fr.document-core#0.1.0: FR Document Core (Modèle métier)(fr)

## Pages

* [Accueil](index.md)
* [Introduction](spec-technique-intro.md)
* [Informations sur la traduction](translationinfo.md)
* [Flux de consommation](spec-technique-flux-consommation.md)
* [Vue d'ensemble](spec-technique-vue-ensemble.md)
* [Autres Ressources](autres_ressources.md)
* [Résumé des artefacts](artifacts.md)
* [Vue d'ensemble](spec-fonctionnelle-intro.md)
* [Téléchargements et usages](annexe-downloads.md)
* [Historique des versions](change-log.md)
* [Alimentation](spec-fonctionnelle-alimentation.md)
* [Sécurité](annexe-securite.md)
* [Flux d'alimentation](spec-technique-flux-alimentation.md)

## Resources

### CodeSystems

* [Compétences CodeSystem](CodeSystem-competence-code-system.md)
* [Type de carte](CodeSystem-type-carte-code-system.md)

### ValueSets

* [EyeColor Value Set](ValueSet-EyeColorVS.md)
* [Melting Pot Value Set](ValueSet-MeltingPotVS.md)
* [ModifiedAdministrativeGender](ValueSet-ModifiedAdministrativeGender.md)
* [Type Carte Value Set](ValueSet-TypeCarteVS.md)

### Resource Profiles

* [Patient français](StructureDefinition-fr-patient.md)

### Extensions

* [EyeColor](StructureDefinition-EyeColor.md)

### ImplementationGuides

* [FR Document Core (Modèle métier)](ImplementationGuide-ans.fr.document-core.md)

### Examples

* [frpatient-exemple (Patient)](Patient-frpatient-exemple.md)
