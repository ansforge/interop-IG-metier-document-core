# Accueil - FR Document Core (Modèle métier) v0.1.0

## Accueil

 
There is no translation page available for the current page, so it has been rendered in the default language 

 **Modèle logique métier des documents dématérialisés produits en France dans le domaine sanitaire et le domaine médico-social.**
 Business logical model of dematerialized health and medico-social documents produced in France. 

>  **Attention !** Cet Implementation Guide n'est pas en version courante. La version courante sera accessible via l'URL canonique suite à la première release : https://interop.esante.gouv.fr/ig/document-core 

**⚠️ Version de test**

Cette publication est une version de test. Elle ne doit pas être utilisée en production.

### Introduction

**Le partage** dans Mon espace santé et **l'échange** par messagerie sécurisée de santé **des documents médicaux et médico-sociaux permet d'améliorer la continuité et la coordination des soins**.

Le Cadre d'interopérabilité des Systèmes d'Information de Santé (CI-SIS) fixe les règles syntaxiques et sémantiques spécifiques à la France et permettant de produire ces documents afin qu'ils soient :

* compréhensibles par les professionnels des secteurs sanitaire et médico-social et les patients/usagers,
* exploitables par les SI pour permettre la mise en œuvre de services à valeurs ajoutées à partir des données structurées contenues dans ces documents.

**Ce guide présente le modèle logique métier générique des documents médicaux et médico-sociaux**, socle commun aux implémentations [FHIR](https://interop.esante.gouv.fr/ig/fhir/document-core) et [CDA](https://interop.esante.gouv.fr/ig/cda/document-core).

Il fait partie du CI-SIS.

### Gouvernance

Ce guide d'implémentation FR Document Core (Modèle métier) est géré par l'Agence du Numérique en Santé (ANS).

### Droits de propriété intellectuelle

**Pour les ressources syntaxiques :**

Ce guide définit un modèle logique métier indépendant de toute syntaxe d'implémentation. Les droits de propriété intellectuelle relatifs aux standards syntaxiques (CDA, FHIR, IHE, DICOM) sont précisés dans les guides d'implémentation associés : [FR Document Core (FHIR)](https://interop.esante.gouv.fr/ig/fhir/document-core) et [FR Document Core (CDA)](https://interop.esante.gouv.fr/ig/cda/document-core).

**Pour les ressources sémantiques :**

Certaines ressources sémantiques de ce guide sont protégées par des droits de propriété intellectuelle couverte par les déclarations ci-dessous. L’utilisation de ces ressources est soumise à l’acceptation et au respect des conditions précisées dans la licence d’utilisation de chacune d’entre elle.

* ISO maintains the copyright on the country codes, and controls its use carefully. For further details see the ISO 3166 web page: [https://www.iso.org/iso-3166-country-codes.html](https://www.iso.org/iso-3166-country-codes.html)

* [ISO 3166-1 Codes for the representation of names of countries and their subdivisions — Part 1: Country code](http://terminology.hl7.org/6.3.0/CodeSystem-ISO3166Part1.html): [ConceptMap/FRAdverseDrugReactionLMCDAFHIR](ConceptMap-FRAdverseDrugReactionLMCDAFHIR.md), [ConceptMap/FRAttachmentLMCDAFHIR](ConceptMap-FRAttachmentLMCDAFHIR.md)... Show 191 more, [ConceptMap/FRDeviceLMCDAFHIR](ConceptMap-FRDeviceLMCDAFHIR.md), [ConceptMap/FRObservationLMCDAFHIR](ConceptMap-FRObservationLMCDAFHIR.md), [ConceptMap/FRPregnancyHistoryLMCDAFHIR](ConceptMap-FRPregnancyHistoryLMCDAFHIR.md), [FRAdvanceDirectiveLMCDAFHIR](ConceptMap-FRAdvanceDirectiveLMCDAFHIR.md), [FRAllergyIntoleranceLMCDAFHIR](ConceptMap-FRAllergyIntoleranceLMCDAFHIR.md), [FRAttesterLMCDAFHIR](ConceptMap-FRAttesterLMCDAFHIR.md), [FRAuthorLMCDAFHIR](ConceptMap-FRAuthorLMCDAFHIR.md), [FRCarePlanLMCDAFHIR](ConceptMap-FRCarePlanLMCDAFHIR.md), [FRConditionLMCDAFHIR](ConceptMap-FRConditionLMCDAFHIR.md), [FRConsentLMCDAFHIR](ConceptMap-FRConsentLMCDAFHIR.md), [FRCustodianLMCDAFHIR](ConceptMap-FRCustodianLMCDAFHIR.md), [FRDataEntererLMCDAFHIR](ConceptMap-FRDataEntererLMCDAFHIR.md), [FRDeviceUseLMCDAFHIR](ConceptMap-FRDeviceUseLMCDAFHIR.md), [FREncounterLMCDAFHIR](ConceptMap-FREncounterLMCDAFHIR.md), [FRFamilyMemberHistoryLMCDAFHIR](ConceptMap-FRFamilyMemberHistoryLMCDAFHIR.md), [FRHealthProfessionalLMCDAFHIR](ConceptMap-FRHealthProfessionalLMCDAFHIR.md), [FRImagingMedicationAministrationLMCDAFHIR](ConceptMap-FRImagingMedicationAministrationLMCDAFHIR.md), [FRImagingProcedureLMCDAFHIR](ConceptMap-FRImagingProcedureLMCDAFHIR.md), [FRImagingQuantityExposureLMCDAFHIR](ConceptMap-FRImagingQuantityExposureLMCDAFHIR.md), [FRImagingSeriesLMCDAFHIR](ConceptMap-FRImagingSeriesLMCDAFHIR.md), [FRImagingStudyLMCDAFHIR](ConceptMap-FRImagingStudyLMCDAFHIR.md), [FRImmunisationLMCDAFHIR](ConceptMap-FRImmunisationLMCDAFHIR.md), [FRInformantLMCDAFHIR](ConceptMap-FRInformantLMCDAFHIR.md), [FRIntendedRecipientLMCDAFHIR](ConceptMap-FRIntendedRecipientLMCDAFHIR.md), [FRLMAddendum](StructureDefinition-FRLMAddendum.md), [FRLMAdmissionEvaluation](StructureDefinition-FRLMAdmissionEvaluation.md), [FRLMAdvanceDirective](StructureDefinition-FRLMAdvanceDirective.md), [FRLMAdvanceDirectives](StructureDefinition-FRLMAdvanceDirectives.md), [FRLMAdverseDrugReaction](StructureDefinition-FRLMAdverseDrugReaction.md), [FRLMAlert](StructureDefinition-FRLMAlert.md), [FRLMAlerts](StructureDefinition-FRLMAlerts.md), [FRLMAllergiesAndIntolerances](StructureDefinition-FRLMAllergiesAndIntolerances.md), [FRLMAllergyIntolerance](StructureDefinition-FRLMAllergyIntolerance.md), [FRLMAttachment](StructureDefinition-FRLMAttachment.md), [FRLMAttachments](StructureDefinition-FRLMAttachments.md), [FRLMAttester](StructureDefinition-FRLMAttester.md), [FRLMBodyStructure](StructureDefinition-FRLMBodyStructure.md), [FRLMCarePlan](StructureDefinition-FRLMCarePlan.md), [FRLMCarePlans](StructureDefinition-FRLMCarePlans.md), [FRLMComparisonStudy](StructureDefinition-FRLMComparisonStudy.md), [FRLMConclusion](StructureDefinition-FRLMConclusion.md), [FRLMCondition](StructureDefinition-FRLMCondition.md), [FRLMConsent](StructureDefinition-FRLMConsent.md), [FRLMCorpsDocument](StructureDefinition-FRLMCorpsDocument.md), [FRLMCourseOfEncounter](StructureDefinition-FRLMCourseOfEncounter.md), [FRLMDICOMMedicationAdministration](StructureDefinition-FRLMDICOMMedicationAdministration.md), [FRLMDataEnterer](StructureDefinition-FRLMDataEnterer.md), [FRLMDevice](StructureDefinition-FRLMDevice.md), [FRLMDeviceUse](StructureDefinition-FRLMDeviceUse.md), [FRLMDicomStudyMetadata](StructureDefinition-FRLMDicomStudyMetadata.md), [FRLMDosageInstructions](StructureDefinition-FRLMDosageInstructions.md), [FRLMDoseNumber](StructureDefinition-FRLMDoseNumber.md), [FRLMEncounter](StructureDefinition-FRLMEncounter.md), [FRLMEncounterInformation](StructureDefinition-FRLMEncounterInformation.md), [FRLMEndpoint](StructureDefinition-FRLMEndpoint.md), [FRLMEntry](StructureDefinition-FRLMEntry.md), [FRLMExaminationReport](StructureDefinition-FRLMExaminationReport.md), [FRLMExposureInformation](StructureDefinition-FRLMExposureInformation.md), [FRLMFamilyMedicalHistory](StructureDefinition-FRLMFamilyMedicalHistory.md), [FRLMFamilyMemberHistory](StructureDefinition-FRLMFamilyMemberHistory.md), [FRLMFunctionalStatus](StructureDefinition-FRLMFunctionalStatus.md), [FRLMHazardousWorkingConditions](StructureDefinition-FRLMHazardousWorkingConditions.md), [FRLMHeaderDocument](StructureDefinition-FRLMHeaderDocument.md), [FRLMHealthProfessional](StructureDefinition-FRLMHealthProfessional.md), [FRLMHistoryOfPastIllness](StructureDefinition-FRLMHistoryOfPastIllness.md), [FRLMHospitalDischargeMedications](StructureDefinition-FRLMHospitalDischargeMedications.md), [FRLMHumanName](StructureDefinition-FRLMHumanName.md), [FRLMImagingStudy](StructureDefinition-FRLMImagingStudy.md), [FRLMImmunisation](StructureDefinition-FRLMImmunisation.md), [FRLMImmunisations](StructureDefinition-FRLMImmunisations.md), [FRLMInformant](StructureDefinition-FRLMInformant.md), [FRLMIntendedRecipient](StructureDefinition-FRLMIntendedRecipient.md), [FRLMLaboratoryObservation](StructureDefinition-FRLMLaboratoryObservation.md), [FRLMLegalAuthentication](StructureDefinition-FRLMLegalAuthentication.md), [FRLMLocation](StructureDefinition-FRLMLocation.md), [FRLMMedicalDevicePrescriptions](StructureDefinition-FRLMMedicalDevicePrescriptions.md), [FRLMMedicalDevicesAndImplants](StructureDefinition-FRLMMedicalDevicesAndImplants.md), [FRLMMedication](StructureDefinition-FRLMMedication.md), [FRLMMedicationAdministration](StructureDefinition-FRLMMedicationAdministration.md), [FRLMMedicationDispensations](StructureDefinition-FRLMMedicationDispensations.md), [FRLMMedicationDispense](StructureDefinition-FRLMMedicationDispense.md), [FRLMMedicationPrescription](StructureDefinition-FRLMMedicationPrescription.md), [FRLMMedicationSummary](StructureDefinition-FRLMMedicationSummary.md), [FRLMMedicationUse](StructureDefinition-FRLMMedicationUse.md), [FRLMNote](StructureDefinition-FRLMNote.md), [FRLMObservation](StructureDefinition-FRLMObservation.md), [FRLMObservationAssessment](StructureDefinition-FRLMObservationAssessment.md), [FRLMObservationMedia](StructureDefinition-FRLMObservationMedia.md), [FRLMObservationResults](StructureDefinition-FRLMObservationResults.md), [FRLMObservationSocialHistory](StructureDefinition-FRLMObservationSocialHistory.md), [FRLMObservationVitalSign](StructureDefinition-FRLMObservationVitalSign.md), [FRLMOrder](StructureDefinition-FRLMOrder.md), [FRLMOrderInformation](StructureDefinition-FRLMOrderInformation.md), [FRLMOrganisation](StructureDefinition-FRLMOrganisation.md), [FRLMParticipant](StructureDefinition-FRLMParticipant.md), [FRLMPatient](StructureDefinition-FRLMPatient.md), [FRLMPatientEducation](StructureDefinition-FRLMPatientEducation.md), [FRLMPatientHistory](StructureDefinition-FRLMPatientHistory.md), [FRLMPatientStory](StructureDefinition-FRLMPatientStory.md), [FRLMPatientTransfer](StructureDefinition-FRLMPatientTransfer.md), [FRLMPredictableAdverseDrugReaction](StructureDefinition-FRLMPredictableAdverseDrugReaction.md), [FRLMPregnancyHistory](StructureDefinition-FRLMPregnancyHistory.md), [FRLMPregnancyObservation](StructureDefinition-FRLMPregnancyObservation.md), [FRLMPregnancyStatus](StructureDefinition-FRLMPregnancyStatus.md), [FRLMPrescriptionEntree](StructureDefinition-FRLMPrescriptionEntree.md), [FRLMPrescriptionItem](StructureDefinition-FRLMPrescriptionItem.md), [FRLMPresentedForm](StructureDefinition-FRLMPresentedForm.md), [FRLMProblems](StructureDefinition-FRLMProblems.md), [FRLMProcedure](StructureDefinition-FRLMProcedure.md), [FRLMProcedures](StructureDefinition-FRLMProcedures.md), [FRLMQRCode](StructureDefinition-FRLMQRCode.md), [FRLMQuantityExposure](StructureDefinition-FRLMQuantityExposure.md), [FRLMReasonForReferral](StructureDefinition-FRLMReasonForReferral.md), [FRLMRecommendation](StructureDefinition-FRLMRecommendation.md), [FRLMRelatedPerson](StructureDefinition-FRLMRelatedPerson.md), [FRLMResultData](StructureDefinition-FRLMResultData.md), [FRLMSOPInstance](StructureDefinition-FRLMSOPInstance.md), [FRLMSection](StructureDefinition-FRLMSection.md), [FRLMSectionPregnancyHistory](StructureDefinition-FRLMSectionPregnancyHistory.md), [FRLMSectionTravelHistory](StructureDefinition-FRLMSectionTravelHistory.md), [FRLMSeries](StructureDefinition-FRLMSeries.md), [FRLMServiceRequest](StructureDefinition-FRLMServiceRequest.md), [FRLMSocialHistory](StructureDefinition-FRLMSocialHistory.md), [FRLMSpecimen](StructureDefinition-FRLMSpecimen.md), [FRLMSupportingInformation](StructureDefinition-FRLMSupportingInformation.md), [FRLMTravelHistory](StructureDefinition-FRLMTravelHistory.md), [FRLMVitalSigns](StructureDefinition-FRLMVitalSigns.md), [FRLaboratoryObservationLMCDAFHIR](ConceptMap-FRLaboratoryObservationLMCDAFHIR.md), [FRLegalAuthenticationLMCDAFHIR](ConceptMap-FRLegalAuthenticationLMCDAFHIR.md), [FRLogicalModelDocumentCore](index.md), [FRMediaLMCDAFHIR](ConceptMap-FRMediaLMCDAFHIR.md), [FRMedicationAdministrationLMCDAFHIR](ConceptMap-FRMedicationAdministrationLMCDAFHIR.md), [FRMedicationDispenseLMCDAFHIR](ConceptMap-FRMedicationDispenseLMCDAFHIR.md), [FRMedicationLMCDAFHIR](ConceptMap-FRMedicationLMCDAFHIR.md), [FRMedicationRequestLMCDAFHIR](ConceptMap-FRMedicationRequestLMCDAFHIR.md), [FRMedicationStatementLMCDAFHIR](ConceptMap-FRMedicationStatementLMCDAFHIR.md), [FRObservationAssessmentLMCDAFHIR](ConceptMap-FRObservationAssessmentLMCDAFHIR.md), [FRObservationMicroorganismDetectionLMCDAFHIR](ConceptMap-FRObservationMicroorganismDetectionLMCDAFHIR.md), [FRObservationMultiresistantMicroorganismsIdentificationLMCDAFHIR](ConceptMap-FRObservationMultiresistantMicroorganismsIdentificationLMCDAFHIR.md), [FRObservationPregnancyLMCDAFHIR](ConceptMap-FRObservationPregnancyLMCDAFHIR.md), [FRObservationResultLMCDAFHIR](ConceptMap-FRObservationResultLMCDAFHIR.md), [FRObservationSocialHistoryLMCDAFHIR](ConceptMap-FRObservationSocialHistoryLMCDAFHIR.md), [FRObservationVitalSignsLMCDAFHIR](ConceptMap-FRObservationVitalSignsLMCDAFHIR.md), [FROrderLMCDAFHIR](ConceptMap-FROrderLMCDAFHIR.md), [FROrganisationLMCDAFHIR](ConceptMap-FROrganisationLMCDAFHIR.md), [FRParticipantCorpsLMCDAFHIR](ConceptMap-FRParticipantCorpsLMCDAFHIR.md), [FRParticipantHeaderLMCDAFHIR](ConceptMap-FRParticipantHeaderLMCDAFHIR.md), [FRPatientLMCDAFHIR](ConceptMap-FRPatientLMCDAFHIR.md), [FRProcedureLMCDAFHIR](ConceptMap-FRProcedureLMCDAFHIR.md), [FRRelatedPersonLMCDAFHIR](ConceptMap-FRRelatedPersonLMCDAFHIR.md), [FRSectionAddendumLMCDAFHIR](ConceptMap-FRSectionAddendumLMCDAFHIR.md), [FRSectionAdvanceDirectivesLMCDAFHIR](ConceptMap-FRSectionAdvanceDirectivesLMCDAFHIR.md), [FRSectionAlertsLMCDAFHIR](ConceptMap-FRSectionAlertsLMCDAFHIR.md), [FRSectionAllergiesAndIntolerancesLMCDAFHIR](ConceptMap-FRSectionAllergiesAndIntolerancesLMCDAFHIR.md), [FRSectionAttachmentsLMCDAFHIR](ConceptMap-FRSectionAttachmentsLMCDAFHIR.md), [FRSectionCarePlansLMCDAFHIR](ConceptMap-FRSectionCarePlansLMCDAFHIR.md), [FRSectionComparisonStudyLMCDAFHIR](ConceptMap-FRSectionComparisonStudyLMCDAFHIR.md), [FRSectionConclusionLMCDAFHIR](ConceptMap-FRSectionConclusionLMCDAFHIR.md), [FRSectionDicomStudyMetadataLMCDAFHIR](ConceptMap-FRSectionDicomStudyMetadataLMCDAFHIR.md), [FRSectionExaminationReportLMCDAFHIR](ConceptMap-FRSectionExaminationReportLMCDAFHIR.md), [FRSectionExposureInformationLMCDAFHIR](ConceptMap-FRSectionExposureInformationLMCDAFHIR.md), [FRSectionFamilyMedicalHistoryLMCDAFHIR](ConceptMap-FRSectionFamilyMedicalHistoryLMCDAFHIR.md), [FRSectionFunctionalStatusLMCDAFHIR](ConceptMap-FRSectionFunctionalStatusLMCDAFHIR.md), [FRSectionHazardousWorkingConditionsLMCDAFHIR](ConceptMap-FRSectionHazardousWorkingConditionsLMCDAFHIR.md), [FRSectionHospitalDischargeMedicationsLMCDAFHIR](ConceptMap-FRSectionHospitalDischargeMedicationsLMCDAFHIR.md), [FRSectionImagingSupportingInformationLMCDAFHIR](ConceptMap-FRSectionImagingSupportingInformationLMCDAFHIR.md), [FRSectionImmunisationsLMCDAFHIR](ConceptMap-FRSectionImmunisationsLMCDAFHIR.md), [FRSectionLaboratorySupportingInformationLMCDAFHIR](ConceptMap-FRSectionLaboratorySupportingInformationLMCDAFHIR.md), [FRSectionMedicalDevicePrescriptionsLMCDAFHIR](ConceptMap-FRSectionMedicalDevicePrescriptionsLMCDAFHIR.md), [FRSectionMedicalDevicesAndImplantsLMCDAFHIR](ConceptMap-FRSectionMedicalDevicesAndImplantsLMCDAFHIR.md), [FRSectionMedicalHistoryLMCDAFHIR](ConceptMap-FRSectionMedicalHistoryLMCDAFHIR.md), [FRSectionMedicationDispenseLMCDAFHIR](ConceptMap-FRSectionMedicationDispenseLMCDAFHIR.md), [FRSectionMedicationRequestLMCDAFHIR](ConceptMap-FRSectionMedicationRequestLMCDAFHIR.md), [FRSectionMedicationSummaryLMCDAFHIR](ConceptMap-FRSectionMedicationSummaryLMCDAFHIR.md), [FRSectionNoteLMCDAFHIR](ConceptMap-FRSectionNoteLMCDAFHIR.md), [FRSectionOrderInformationLMCDAFHIR](ConceptMap-FRSectionOrderInformationLMCDAFHIR.md), [FRSectionPatientEducationLMCDAFHIR](ConceptMap-FRSectionPatientEducationLMCDAFHIR.md), [FRSectionPredictableAdverseDrugReactionLMCDAFHIR](ConceptMap-FRSectionPredictableAdverseDrugReactionLMCDAFHIR.md), [FRSectionPregnancyHistoryLMCDAFHIR](ConceptMap-FRSectionPregnancyHistoryLMCDAFHIR.md), [FRSectionPresentedFormLMCDAFHIR](ConceptMap-FRSectionPresentedFormLMCDAFHIR.md), [FRSectionProblemsLMCDAFHIR](ConceptMap-FRSectionProblemsLMCDAFHIR.md), [FRSectionProceduresLMCDAFHIR](ConceptMap-FRSectionProceduresLMCDAFHIR.md), [FRSectionQRCodeLMCDAFHIR](ConceptMap-FRSectionQRCodeLMCDAFHIR.md), [FRSectionReasonForReferralLMCDAFHIR](ConceptMap-FRSectionReasonForReferralLMCDAFHIR.md), [FRSectionResultDataLMCDAFHIR](ConceptMap-FRSectionResultDataLMCDAFHIR.md), [FRSectionResultsLMCDAFHIR](ConceptMap-FRSectionResultsLMCDAFHIR.md), [FRSectionSocialHistoryLMCDAFHIR](ConceptMap-FRSectionSocialHistoryLMCDAFHIR.md), [FRSectionVitalSignsLMCDAFHIR](ConceptMap-FRSectionVitalSignsLMCDAFHIR.md), [FRServiceRequestLMCDAFHIR](ConceptMap-FRServiceRequestLMCDAFHIR.md), [FRSpecimenLMCDAFHIR](ConceptMap-FRSpecimenLMCDAFHIR.md) and [Mapping Métier/CDA/FHIR : Entête d'un document](ConceptMap-FRHeaderDocumentLMCDAFHIR.md)


* The UCUM codes, UCUM table (regardless of format), and UCUM Specification are copyright 1999-2009, Regenstrief Institute, Inc. and the Unified Codes for Units of Measures (UCUM) Organization. All rights reserved. [https://ucum.org/trac/wiki/TermsOfUse](https://ucum.org/trac/wiki/TermsOfUse)

* [Unified Code for Units of Measure (UCUM)](http://hl7.org/fhir/uv/xver-r5.r4/0.1.0/CodeSystem-v3-ucum.html): [FRLMDosageInstructions](StructureDefinition-FRLMDosageInstructions.md)


* These codes are excerpted from Digital Imaging and Communications in Medicine (DICOM) Standard, Part 16: Content Mapping Resource, Copyright © 2011 by the National Electrical Manufacturers Association.

* [DICOM Controlled Terminology Definitions](http://hl7.org/fhir/R4/codesystem-dicom-dcim.html): [FRLMImagingStudy](StructureDefinition-FRLMImagingStudy.md), [FRLMQuantityExposure](StructureDefinition-FRLMQuantityExposure.md) and [FRLMSeries](StructureDefinition-FRLMSeries.md)


* This artifact includes content from EDQM Standard Terms. EDQM Standard Terms are copyright European Directorate for the Quality of Medicines. Terms & Conditions in https://www.edqm.eu/en/standard-terms-database

* : [FRLMDosageInstructions](StructureDefinition-FRLMDosageInstructions.md)


* This material contains content from [LOINC](http://loinc.org). LOINC is copyright © 1995-2020, Regenstrief Institute, Inc. and the Logical Observation Identifiers Names and Codes (LOINC) Committee and is available at no cost under the [license](http://loinc.org/license). LOINC® is a registered United States trademark of Regenstrief Institute, Inc.

* [LOINC](http://terminology.hl7.org/6.3.0/CodeSystem-v3-loinc.html): [FRLMAdvanceDirective](StructureDefinition-FRLMAdvanceDirective.md), [FRLMObservationSocialHistory](StructureDefinition-FRLMObservationSocialHistory.md), [FRLMObservationVitalSign](StructureDefinition-FRLMObservationVitalSign.md) and [FRLMPregnancyHistory](StructureDefinition-FRLMPregnancyHistory.md)


* This material contains content that is copyright of SNOMED International. Implementers of these specifications must have the appropriate SNOMED CT Affiliate license - for more information contact [https://www.snomed.org/get-snomed](https://www.snomed.org/get-snomed) or [info@snomed.org](mailto:info@snomed.org).

* [SNOMED Clinical Terms&reg; (SNOMED CT&reg;)](http://hl7.org/fhir/R4/codesystem-snomedct.html): [FRLMAdvanceDirective](StructureDefinition-FRLMAdvanceDirective.md), [FRLMAdverseDrugReaction](StructureDefinition-FRLMAdverseDrugReaction.md)... Show 7 more, [FRLMAllergyIntolerance](StructureDefinition-FRLMAllergyIntolerance.md), [FRLMBodyStructure](StructureDefinition-FRLMBodyStructure.md), [FRLMCondition](StructureDefinition-FRLMCondition.md), [FRLMEncounter](StructureDefinition-FRLMEncounter.md), [FRLMFamilyMemberHistory](StructureDefinition-FRLMFamilyMemberHistory.md), [FRLMPregnancyObservation](StructureDefinition-FRLMPregnancyObservation.md) and [FRLMPregnancyStatus](StructureDefinition-FRLMPregnancyStatus.md)


* This material derives from the HL7 Terminology (THO). THO is copyright ©1989+ Health Level Seven International and is made available under the CC0 designation. For more licensing information see: [https://terminology.hl7.org/license.html](https://terminology.hl7.org/license.html)

* [AllergyIntolerance Clinical Status Codes](http://terminology.hl7.org/7.4.0/CodeSystem-allergyintolerance-clinical.html): [FRLMAllergyIntolerance](StructureDefinition-FRLMAllergyIntolerance.md)
* [Condition Clinical Status Codes](https://interop.esante.gouv.fr/terminologies/1.14.0/CodeSystem-condition-clinical.html): [FRLMCondition](StructureDefinition-FRLMCondition.md)
* [ConditionVerificationStatus](https://interop.esante.gouv.fr/terminologies/1.14.0/CodeSystem-condition-ver-status.html): [FRLMAllergyIntolerance](StructureDefinition-FRLMAllergyIntolerance.md) and [FRLMCondition](StructureDefinition-FRLMCondition.md)
* [specimenType](https://interop.esante.gouv.fr/terminologies/1.14.0/CodeSystem-v2-0487.html): [FRLMSpecimen](StructureDefinition-FRLMSpecimen.md)
* [ActCode](http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActCode.html): [FRLMMedicationDispense](StructureDefinition-FRLMMedicationDispense.md)
* [ActStatus](http://terminology.hl7.org/7.4.0/CodeSystem-v3-ActStatus.html): [FRLMProcedure](StructureDefinition-FRLMProcedure.md)
* [AdministrativeGender](http://terminology.hl7.org/7.4.0/CodeSystem-v3-AdministrativeGender.html): [FRLMRelatedPerson](StructureDefinition-FRLMRelatedPerson.md)
* [ObservationInterpretation](http://terminology.hl7.org/7.4.0/CodeSystem-v3-ObservationInterpretation.html): [FRLMObservation](StructureDefinition-FRLMObservation.md) and [FRLMObservationVitalSign](StructureDefinition-FRLMObservationVitalSign.md)
* [ParticipationType](http://terminology.hl7.org/7.4.0/CodeSystem-v3-ParticipationType.html): [FRLMParticipant](StructureDefinition-FRLMParticipant.md)
* [RoleCode](http://terminology.hl7.org/7.4.0/CodeSystem-v3-RoleCode.html): [FRLMRelatedPerson](StructureDefinition-FRLMRelatedPerson.md)
* [SpecimenType](http://terminology.hl7.org/7.4.0/CodeSystem-v3-SpecimenType.html): [FRLMSpecimen](StructureDefinition-FRLMSpecimen.md)
* [Substance Admin Substitution](http://terminology.hl7.org/7.4.0/CodeSystem-v3-substanceAdminSubstitution.html): [FRLMPrescriptionItem](StructureDefinition-FRLMPrescriptionItem.md)


Les terminologies publiées sur le [Serveur Multi-terminologies (SMT)](https://smt.esante.gouv.fr/) de l'ANS précisent la licence d'utilisation associée.

Pour les terminologies qui ne sont pas publiées dans le SMT, se renseigner auprès de l'unité de production.

### Dépendances





















