# Logical model - FR LM Vital Signs - FR Document Core (Modèle métier) v0.1.0

## Logical Model: Logical model - FR LM Vital Signs 

**Usages:**

* Use this Logical Model: [Logical model - FR LM Corps document](StructureDefinition-FRLMCorpsDocument.md)

You can also check for [usages in the FHIR IG Statistics](https://packages2.fhir.org/xig/resource/ans.fr.document-core|current/StructureDefinition/StructureDefinition-FRLMVitalSigns.json)

### Formal Views of Profile Content

 [Description Differentials, Snapshots, and other representations](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#structure-definitions). 

 

Other representations of profile: [CSV](../StructureDefinition-FRLMVitalSigns.csv), [Excel](../StructureDefinition-FRLMVitalSigns.xlsx) 



## Resource Content

```json
{
  "resourceType" : "StructureDefinition",
  "id" : "FRLMVitalSigns",
  "extension" : [{
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-type-characteristics",
    "valueCode" : "can-be-target"
  },
  {
    "url" : "http://hl7.org/fhir/StructureDefinition/structuredefinition-type-characteristics",
    "valueCode" : "can-be-target"
  }],
  "url" : "https://interop.esante.gouv.fr/ig/document-core/StructureDefinition/FRLMVitalSigns",
  "version" : "0.1.0",
  "name" : "FRLMVitalSigns",
  "title" : "Logical model - FR LM Vital Signs",
  "status" : "draft",
  "date" : "2026-10-08T13:13:48+00:00",
  "publisher" : "Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris",
  "contact" : [{
    "name" : "Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris",
    "telecom" : [{
      "system" : "url",
      "value" : "https://esante.gouv.fr"
    }]
  }],
  "description" : "Section Signes vitaux",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "FR",
      "display" : "France (la)"
    }]
  }],
  "fhirVersion" : "4.0.1",
  "kind" : "logical",
  "abstract" : false,
  "type" : "https://interop.esante.gouv.fr/ig/document-core/StructureDefinition/FRLMVitalSigns",
  "baseDefinition" : "https://interop.esante.gouv.fr/ig/document-core/StructureDefinition/FRLMSection|0.1.0",
  "derivation" : "specialization",
  "differential" : {
    "element" : [{
      "id" : "FRLMVitalSigns",
      "path" : "FRLMVitalSigns",
      "short" : "Logical model - FR LM Vital Signs",
      "definition" : "Section Signes vitaux"
    },
    {
      "id" : "FRLMVitalSigns.titleSection",
      "path" : "FRLMVitalSigns.titleSection",
      "min" : 1
    },
    {
      "id" : "FRLMVitalSigns.subSection",
      "path" : "FRLMVitalSigns.subSection",
      "max" : "0"
    },
    {
      "id" : "FRLMVitalSigns.entry.observationVitalSign",
      "path" : "FRLMVitalSigns.entry.observationVitalSign",
      "short" : "Signes vitaux",
      "definition" : "Signes vitaux",
      "min" : 1,
      "max" : "*",
      "type" : [{
        "code" : "https://interop.esante.gouv.fr/ig/document-core/StructureDefinition/FRLMObservationVitalSign"
      }]
    }]
  }
}

```
