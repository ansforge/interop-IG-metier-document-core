# Mapping FRLMComparisonStudy → FRCDADICOMExamenComparatif / FRLMComparisonStudy → FRCompositionDocument.section:sectionComparison - FR Document Core (Modèle métier) v0.1.0

## ConceptMap: Mapping FRLMComparisonStudy → FRCDADICOMExamenComparatif / FRLMComparisonStudy → FRCompositionDocument.section:sectionComparison 



## Resource Content

```json
{
  "resourceType" : "ConceptMap",
  "id" : "FRSectionComparisonStudyLMCDAFHIR",
  "url" : "https://interop.esante.gouv.fr/ig/document-core/ConceptMap/FRSectionComparisonStudyLMCDAFHIR",
  "version" : "0.1.0",
  "name" : "FRSectionComparisonStudyLMCDAFHIR",
  "title" : "Mapping Métier/CDA/FHIR : \"Comparaison d'examens d'imagerie\"",
  "status" : "draft",
  "experimental" : false,
  "date" : "2026-10-08T13:13:48+00:00",
  "publisher" : "Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris",
  "contact" : [{
    "name" : "Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris",
    "telecom" : [{
      "system" : "url",
      "value" : "https://esante.gouv.fr"
    }]
  }],
  "description" : "Mapping des éléments du modèle métier FRLMComparisonStudy vers le profil CDA FRCDADICOMExamenComparatif, puis vers la section FHIR FRCompositionDocument.section:sectionComparison.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "FR",
      "display" : "France (la)"
    }]
  }],
  "group" : [{
    "source" : "https://interop.esante.gouv.fr/ig/document-core/StructureDefinition/FRLMComparisonStudy",
    "sourceVersion" : "0.1.0",
    "target" : "https://interop.esante.gouv.fr/ig/cda/document-core/StructureDefinition/fr-cda-dicom-examen-comparatif",
    "targetVersion" : "0.1.0",
    "element" : [{
      "code" : "FRLMComparisonStudy",
      "target" : [{
        "code" : "Section",
        "display" : "FRCDASectionDICOMExamenComparatif",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "FRLMComparisonStudy.codeSection",
      "target" : [{
        "code" : "Section.code",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "FRLMComparisonStudy.titleSection",
      "target" : [{
        "code" : "Section.title",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "FRLMComparisonStudy.description",
      "target" : [{
        "code" : "Section.text",
        "equivalence" : "equivalent"
      }]
    }]
  },
  {
    "source" : "https://interop.esante.gouv.fr/ig/document-core/StructureDefinition/FRLMComparisonStudy",
    "sourceVersion" : "0.1.0",
    "target" : "https://interop.esante.gouv.fr/ig/fhir/document-core/StructureDefinition/fr-composition-document",
    "targetVersion" : "0.1.0",
    "element" : [{
      "code" : "FRLMComparisonStudy",
      "target" : [{
        "code" : "Composition.section",
        "display" : "FRCompositionDocument.section:sectionComparison",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "FRLMComparisonStudy.codeSection",
      "target" : [{
        "code" : "Composition.section.code",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "FRLMComparisonStudy.titleSection",
      "target" : [{
        "code" : "Composition.section.title",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "FRLMComparisonStudy.description",
      "target" : [{
        "code" : "Composition.section.text",
        "equivalence" : "equivalent"
      }]
    }]
  }]
}

```
