# Mapping FRLMHazardousWorkingConditions → FRCDAFacteursDeRisqueProfessionnelsNonCode / FRLMHazardousWorkingConditions → FRCompositionDocument.section:sectionUncodedOccupationalRiskFactors - FR Document Core (Modèle métier) v0.1.0

## ConceptMap: Mapping FRLMHazardousWorkingConditions → FRCDAFacteursDeRisqueProfessionnelsNonCode / FRLMHazardousWorkingConditions → FRCompositionDocument.section:sectionUncodedOccupationalRiskFactors 



## Resource Content

```json
{
  "resourceType" : "ConceptMap",
  "id" : "FRSectionHazardousWorkingConditionsLMCDAFHIR",
  "url" : "https://interop.esante.gouv.fr/ig/document-core/ConceptMap/FRSectionHazardousWorkingConditionsLMCDAFHIR",
  "version" : "0.1.0",
  "name" : "FRSectionHazardousWorkingConditionsLMCDAFHIR",
  "title" : "Mapping Métier/CDA/FHIR : \"Facteurs de risque professionnels\"",
  "status" : "draft",
  "experimental" : false,
  "date" : "2026-10-08T13:13:48+00:00",
  "publisher" : "Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris",
  "contact" : [{
    "name" : "Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris",
    "telecom" : [{
      "system" : "url",
      "value" : "https://esante.gouv.fr"
    }]
  }],
  "description" : "Mapping des éléments du modèle métier FRLMHazardousWorkingConditions vers la section CDA FRCDAFacteursDeRisqueProfessionnelsNonCode, puis vers le profil FHIR FRCompositionDocument.section:sectionUncodedOccupationalRiskFactors.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "FR",
      "display" : "France (la)"
    }]
  }],
  "group" : [{
    "source" : "https://interop.esante.gouv.fr/ig/document-core/StructureDefinition/FRLMHazardousWorkingConditions",
    "sourceVersion" : "0.1.0",
    "target" : "https://interop.esante.gouv.fr/ig/cda/document-core/StructureDefinition/fr-cda-facteurs-de-risque-professionnels-non-code",
    "targetVersion" : "0.1.0",
    "element" : [{
      "code" : "FRLMHazardousWorkingConditions",
      "target" : [{
        "code" : "Section",
        "display" : "FRCDASectionFacteursDeRisqueProfessionnelsNonCode",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "FRLMHazardousWorkingConditions.codeSection",
      "target" : [{
        "code" : "Section.code",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "FRLMHazardousWorkingConditions.titleSection",
      "target" : [{
        "code" : "Section.title",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "FRLMHazardousWorkingConditions.description",
      "target" : [{
        "code" : "Section.text",
        "equivalence" : "equivalent"
      }]
    }]
  },
  {
    "source" : "https://interop.esante.gouv.fr/ig/document-core/StructureDefinition/FRLMHazardousWorkingConditions",
    "sourceVersion" : "0.1.0",
    "target" : "https://interop.esante.gouv.fr/ig/fhir/document-core/StructureDefinition/fr-composition-document",
    "targetVersion" : "0.1.0",
    "element" : [{
      "code" : "FRLMHazardousWorkingConditions",
      "target" : [{
        "code" : "Composition.section",
        "display" : "FRCompositionDocument.section:sectionUncodedOccupationalRiskFactors",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "FRLMHazardousWorkingConditions.codeSection",
      "target" : [{
        "code" : "Composition.section.code",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "FRLMHazardousWorkingConditions.titleSection",
      "target" : [{
        "code" : "Composition.section.title",
        "equivalence" : "equivalent"
      }]
    },
    {
      "code" : "FRLMHazardousWorkingConditions.description",
      "target" : [{
        "code" : "Composition.section.text",
        "equivalence" : "equivalent"
      }]
    }]
  }]
}

```
