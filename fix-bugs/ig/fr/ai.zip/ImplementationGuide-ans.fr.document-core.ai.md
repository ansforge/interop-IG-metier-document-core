# Resource FR Document Core (Modèle métier)



## Resource Content

```json
{
  "resourceType" : "ImplementationGuide",
  "id" : "ans.fr.document-core",
  "language" : "fr",
  "url" : "https://interop.esante.gouv.fr/ig/document-core/ImplementationGuide/ans.fr.document-core",
  "version" : "0.1.0",
  "name" : "FRDocumentCore",
  "title" : "FR Document Core (Modèle métier)",
  "status" : "draft",
  "date" : "2026-08-10T19:10:11+00:00",
  "publisher" : "Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris",
  "contact" : [{
    "name" : "Agence du Numérique en Santé (ANS) - 2-10 Rue d'Oradour-sur-Glane, 75015 Paris",
    "telecom" : [{
      "system" : "url",
      "value" : "https://esante.gouv.fr"
    }]
  }],
  "description" : "Volet modèle métier du guide d'implémentation Document Core.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "urn:iso:std:iso:3166",
      "code" : "FR",
      "display" : "France (la)"
    }]
  }],
  "packageId" : "ans.fr.document-core",
  "license" : "CC0-1.0",
  "fhirVersion" : ["4.0.1"],
  "dependsOn" : [{
    "id" : "hl7tx",
    "extension" : [{
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-dependency-comment",
      "valueMarkdown" : "Automatically added as a dependency - all IGs depend on HL7 Terminology"
    }],
    "uri" : "http://terminology.hl7.org/ImplementationGuide/hl7.terminology",
    "packageId" : "hl7.terminology.r4",
    "version" : "7.3.0"
  },
  {
    "id" : "hl7ext",
    "extension" : [{
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-dependency-comment",
      "valueMarkdown" : "Automatically added as a dependency - all IGs depend on the HL7 Extension Pack"
    }],
    "uri" : "http://hl7.org/fhir/extensions/ImplementationGuide/hl7.fhir.uv.extensions",
    "packageId" : "hl7.fhir.uv.extensions.r4",
    "version" : "5.3.0"
  },
  {
    "id" : "ans_fr_terminologies",
    "uri" : "https://interop.esante.gouv.fr/terminologies/ImplementationGuide/ans.fr.terminologies",
    "packageId" : "ans.fr.terminologies",
    "version" : "1.11.1"
  },
  {
    "id" : "ans_fhir_fr_document_core",
    "uri" : "https://interop.esante.gouv.fr/ig/fhir/document-core/ImplementationGuide/ans.fhir.fr.document-core",
    "packageId" : "ans.fhir.fr.document-core",
    "version" : "current"
  },
  {
    "id" : "ans_cda_fr_document_core",
    "uri" : "https://interop.esante.gouv.fr/ig/cda/document-core/ImplementationGuide/ans.cda.fr.document-core",
    "packageId" : "ans.cda.fr.document-core",
    "version" : "current"
  }],
  "definition" : {
    "extension" : [{
      "extension" : [{
        "url" : "code",
        "valueString" : "copyrightyear"
      },
      {
        "url" : "value",
        "valueString" : "2020+"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "releaselabel"
      },
      {
        "url" : "value",
        "valueString" : "ci-build"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "shownav"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-expansion-params"
      },
      {
        "url" : "value",
        "valueString" : "../../expansion-params.json"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "pin-canonicals"
      },
      {
        "url" : "value",
        "valueString" : "pin-all"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-contact"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "logging"
      },
      {
        "url" : "value",
        "valueString" : "tx"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "logging"
      },
      {
        "url" : "value",
        "valueString" : "html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "logging"
      },
      {
        "url" : "value",
        "valueString" : "generate"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "logging"
      },
      {
        "url" : "value",
        "valueString" : "init"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "logging"
      },
      {
        "url" : "value",
        "valueString" : "progress"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "i18n-default-lang"
      },
      {
        "url" : "value",
        "valueString" : "fr"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-jurisdiction"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "i18n-lang"
      },
      {
        "url" : "value",
        "valueString" : "en"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "translation-sources"
      },
      {
        "url" : "value",
        "valueString" : "input/translations/en"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "autoload-resources"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-liquid"
      },
      {
        "url" : "value",
        "valueString" : "template/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-liquid"
      },
      {
        "url" : "value",
        "valueString" : "input/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-qa"
      },
      {
        "url" : "value",
        "valueString" : "temp/qa"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-temp"
      },
      {
        "url" : "value",
        "valueString" : "temp/pages"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-output"
      },
      {
        "url" : "value",
        "valueString" : "output"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-suppressed-warnings"
      },
      {
        "url" : "value",
        "valueString" : "input/ignoreWarnings.txt"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "path-history"
      },
      {
        "url" : "value",
        "valueString" : "https://interop.esante.gouv.fr/ig/document-core/history.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "template-html"
      },
      {
        "url" : "value",
        "valueString" : "template-page.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "template-md"
      },
      {
        "url" : "value",
        "valueString" : "template-page-md.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-context"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-copyright"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-license"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-publisher"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-version"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "apply-wg"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "active-tables"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "fmm-definition"
      },
      {
        "url" : "value",
        "valueString" : "http://hl7.org/fhir/versions.html#maturity"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "propagate-status"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "excludelogbinaryformat"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueString" : "tabbed-snapshots"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/expansion-parameters",
      "valueReference" : {
        "reference" : "Parameters/expansion-parameters"
      }
    },
    {
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-internal-dependency",
      "valueCode" : "hl7.fhir.uv.tools.r4#1.1.2"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "copyrightyear"
      },
      {
        "url" : "value",
        "valueString" : "2020+"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "releaselabel"
      },
      {
        "url" : "value",
        "valueString" : "ci-build"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "shownav"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-expansion-params"
      },
      {
        "url" : "value",
        "valueString" : "../../expansion-params.json"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "pin-canonicals"
      },
      {
        "url" : "value",
        "valueString" : "pin-all"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-contact"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "logging"
      },
      {
        "url" : "value",
        "valueString" : "tx"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "logging"
      },
      {
        "url" : "value",
        "valueString" : "html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "logging"
      },
      {
        "url" : "value",
        "valueString" : "generate"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "logging"
      },
      {
        "url" : "value",
        "valueString" : "init"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "logging"
      },
      {
        "url" : "value",
        "valueString" : "progress"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "i18n-default-lang"
      },
      {
        "url" : "value",
        "valueString" : "fr"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-jurisdiction"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "i18n-lang"
      },
      {
        "url" : "value",
        "valueString" : "en"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "translation-sources"
      },
      {
        "url" : "value",
        "valueString" : "input/translations/en"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "autoload-resources"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-liquid"
      },
      {
        "url" : "value",
        "valueString" : "template/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-liquid"
      },
      {
        "url" : "value",
        "valueString" : "input/liquid"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-qa"
      },
      {
        "url" : "value",
        "valueString" : "temp/qa"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-temp"
      },
      {
        "url" : "value",
        "valueString" : "temp/pages"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-output"
      },
      {
        "url" : "value",
        "valueString" : "output"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-suppressed-warnings"
      },
      {
        "url" : "value",
        "valueString" : "input/ignoreWarnings.txt"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "path-history"
      },
      {
        "url" : "value",
        "valueString" : "https://interop.esante.gouv.fr/ig/document-core/history.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "template-html"
      },
      {
        "url" : "value",
        "valueString" : "template-page.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "template-md"
      },
      {
        "url" : "value",
        "valueString" : "template-page-md.html"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-context"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-copyright"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-license"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-publisher"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-version"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "apply-wg"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "active-tables"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "fmm-definition"
      },
      {
        "url" : "value",
        "valueString" : "http://hl7.org/fhir/versions.html#maturity"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "propagate-status"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "excludelogbinaryformat"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    },
    {
      "extension" : [{
        "url" : "code",
        "valueCode" : "tabbed-snapshots"
      },
      {
        "url" : "value",
        "valueString" : "true"
      }],
      "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
    }],
    "grouping" : [{
      "id" : "header-models",
      "name" : "Modèles logiques métier de l'entête d'un document"
    },
    {
      "id" : "section-models",
      "name" : "Modèles logiques métier des sections d'un document",
      "description" : "Modèles de données métier représentant les sections d'un document."
    },
    {
      "id" : "common-models",
      "name" : "Modèles logiques métier des composants communs",
      "description" : "Modèles de données métier représentant les concepts communs, modélisés indépendamment de la syntaxe et de façon plus accessible pour le métier que les éléments techniques CDA et FHIR."
    },
    {
      "id" : "header-mappings",
      "name" : "Concept Maps de l'entête du document"
    },
    {
      "id" : "section-mappings",
      "name" : "Concept Maps des sections d'un document"
    },
    {
      "id" : "common-mappings",
      "name" : "Concept Maps des composants communs d'un Document"
    }],
    "resource" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-patient-history.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-patient-history"
      },
      "name" : "Logical model  - FR LM Patient History",
      "description" : "Section Historique du patient",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-section-pregnancy-history.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-section-pregnancy-history"
      },
      "name" : "Logical model  - FR LM Pregnancy History",
      "description" : "Section Historique des grossesses",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-section-travel-history.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-section-travel-history"
      },
      "name" : "Logical model  - FR LM Travel History",
      "description" : "Section Historique des voyages",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-device.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-device"
      },
      "name" : "Logical model - Device",
      "description" : "Dispositif médical",
      "exampleBoolean" : false,
      "groupingId" : "common-models"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-addendum.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-addendum"
      },
      "name" : "Logical model - FR LM Addendum",
      "description" : "Section Addendum",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-admission-evaluation.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-admission-evaluation"
      },
      "name" : "Logical model - FR LM Admission Evaluation",
      "description" : "Section Évaluation à l'admission",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-advance-directive.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-advance-directive"
      },
      "name" : "Logical model - FR LM Advance Directive",
      "description" : "Directive anticipée",
      "exampleBoolean" : false,
      "groupingId" : "common-models"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-advance-directives.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-advance-directives"
      },
      "name" : "Logical model - FR LM Advance Directives",
      "description" : "Section Directives anticipées",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-alert.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-alert"
      },
      "name" : "Logical model - FR LM Alert",
      "description" : "Points de vigilances",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-alerts.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-alerts"
      },
      "name" : "Logical model - FR LM Alerts",
      "description" : "Section Points de vigilance",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-allergies-and-intolerances.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-allergies-and-intolerances"
      },
      "name" : "Logical model - FR LM Allergies And Intolerances",
      "description" : "Section Allergies et hypersensibilités",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-allergy-intolerance.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-allergy-intolerance"
      },
      "name" : "Logical model - FR LM Allergy Intolerance",
      "description" : "Allergie ou Hypersensibilité",
      "exampleBoolean" : false,
      "groupingId" : "common-models"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-observation-assessment.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-observation-assessment"
      },
      "name" : "Logical model - FR LM Assessment",
      "description" : "Evaluation",
      "exampleBoolean" : false,
      "groupingId" : "common-models"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-attachment.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-attachment"
      },
      "name" : "Logical model - FR LM Attachment",
      "description" : "Document attaché",
      "exampleBoolean" : false,
      "groupingId" : "common-models"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-attachments.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-attachments"
      },
      "name" : "Logical model - FR LM Attachments",
      "description" : "Section Documents ajoutés",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-attester.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-attester"
      },
      "name" : "Logical model - FR LM Attester",
      "description" : "Professionnel attestant la validité des informations portées dans le document sans pour autant en prendre la responsabilité. N'est pas utilisé dans un document d'expression personnelle du patient/usager et un document produit par un système.",
      "exampleBoolean" : false,
      "groupingId" : "header-models"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-body-structure.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-body-structure"
      },
      "name" : "Logical model - FR LM Body Structure",
      "description" : "Localisation anatomique",
      "exampleBoolean" : false,
      "groupingId" : "common-models"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-care-plan.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-care-plan"
      },
      "name" : "Logical model - FR LM Care Plan",
      "description" : "Plan de soins",
      "exampleBoolean" : false,
      "groupingId" : "common-models"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-care-plans.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-care-plans"
      },
      "name" : "Logical model - FR LM CarePlans",
      "description" : "Section Plan de soins",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-comparison-study.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-comparison-study"
      },
      "name" : "Logical model - FR LM Comparison Study",
      "description" : "Section Comparaison d'examens d'imagerie",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-result-data.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-result-data"
      },
      "name" : "Logical model - FR LM Compte rendu de biologie de 1er niveau",
      "description" : "Section Compte rendu de biologie de 1er niveau",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-conclusion.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-conclusion"
      },
      "name" : "Logical model - FR LM Conclusion",
      "description" : "Section Conclusion",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-condition.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-condition"
      },
      "name" : "Logical model - FR LM Condition",
      "description" : "Problème",
      "exampleBoolean" : false,
      "groupingId" : "common-models"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-consent.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-consent"
      },
      "name" : "Logical model - FR LM Consent",
      "description" : "Permet de documenter qu'un consentement éclairé a été obtenu et d'indiquer quel type de consentement a été fourni.",
      "exampleBoolean" : false,
      "groupingId" : "header-models"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-corps-document.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-corps-document"
      },
      "name" : "Logical model - FR LM Corps document",
      "description" : "Eléments métier du corps d'un document contenant les sections du document.",
      "exampleBoolean" : false,
      "groupingId" : "section-models"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-course-of-encounter.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-course-of-encounter"
      },
      "name" : "Logical model - FR LM Course of encounter",
      "description" : "Section Résultats d'événements",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-data-enterer.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-data-enterer"
      },
      "name" : "Logical model - FR LM Data Enterer",
      "description" : "Opérateur de saisie de la totalité ou d'une partie du contenu du document.",
      "exampleBoolean" : false,
      "groupingId" : "header-models"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-device-use.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-device-use"
      },
      "name" : "Logical model - FR LM Device use",
      "description" : "Dispositif médical usage",
      "exampleBoolean" : false,
      "groupingId" : "common-models"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-dicom-medication-administration.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-dicom-medication-administration"
      },
      "name" : "Logical model - FR LM DICOM Medication Administration",
      "description" : "Administration de produit de santé dans le contexte de l'imagerie médicale",
      "exampleBoolean" : false,
      "groupingId" : "common-models"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-dicom-study-metadata.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-dicom-study-metadata"
      },
      "name" : "Logical model - FR LM DICOM Study Metadata",
      "description" : "Section Object Catalog",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-dose-number.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-dose-number"
      },
      "name" : "Logical model - FR LM Dose Number",
      "description" : "Rang de la vaccination",
      "exampleBoolean" : false,
      "groupingId" : "common-models"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-encounter.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-encounter"
      },
      "name" : "Logical model - FR LM Encounter",
      "description" : "Rencontre",
      "exampleBoolean" : false,
      "groupingId" : "common-models"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-encounter-information.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-encounter-information"
      },
      "name" : "Logical model - FR LM Encounter Information",
      "description" : "Section Informations sur la rencontre",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-endpoint.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-endpoint"
      },
      "name" : "Logical model - FR LM Endpoint",
      "description" : "Référence Wado d'un objet DICOM (SOP Instance)",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-entry.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-entry"
      },
      "name" : "Logical model - FR LM Entry",
      "description" : "Modèle logique représentant l'entrée",
      "exampleBoolean" : false,
      "groupingId" : "common-models"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-examination-report.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-examination-report"
      },
      "name" : "Logical model - FR LM Examination Report",
      "description" : "Section Acte d'imagerie",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-exposure-information.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-exposure-information"
      },
      "name" : "Logical model - FR LM Exposure Information",
      "description" : "Section Exposition aux radiations",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-family-medical-history.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-family-medical-history"
      },
      "name" : "Logical model - FR LM Family Medical History",
      "description" : "Section Antécédents familiaux",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-family-member-history.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-family-member-history"
      },
      "name" : "Logical model - FR LM Family Member History",
      "description" : "Antécédent familial",
      "exampleBoolean" : false,
      "groupingId" : "common-models"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-medication-prescription.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-medication-prescription"
      },
      "name" : "Logical model - FR LM FR LM Medication Prescription",
      "description" : "Section Prescription de médicaments",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-history-of-past-illness.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-history-of-past-illness"
      },
      "name" : "Logical model - FR LM FRLM History Of Past Illness",
      "description" : "Section Antécédents médicaux",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-hazardous-working-conditions.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-hazardous-working-conditions"
      },
      "name" : "Logical model - FR LM Hazardous Working Conditions",
      "description" : "Section Facteurs de risque professionnels non codés",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-header-document.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-header-document"
      },
      "name" : "Logical model - FR LM Header Document",
      "description" : "Eléments de l'entête d'un document contenant les informations générales et nécessaires à la gestion du document (identification et type du document, patient/usager, auteur, évènement documenté, etc...).",
      "exampleBoolean" : false,
      "groupingId" : "header-models"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-health-professional.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-health-professional"
      },
      "name" : "Logical model - FR LM Health Professional",
      "description" : "Une personne (professionnel ou patient ou autre)",
      "exampleBoolean" : false,
      "groupingId" : "header-models"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-hospital-discharge-medications.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-hospital-discharge-medications"
      },
      "name" : "Logical model - FR LM Hospital Discharge Medications",
      "description" : "Section Traitements à la sortie",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-human-name.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-human-name"
      },
      "name" : "Logical model - FR LM Human Name",
      "description" : "Modele logique metier - FR LM Human Name",
      "exampleBoolean" : false,
      "groupingId" : "header-models"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-imaging-study.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-imaging-study"
      },
      "name" : "Logical model - FR LM Imaging Study",
      "description" : "DICOM Examen Imagerie",
      "exampleBoolean" : false,
      "groupingId" : "common-models"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-immunisation.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-immunisation"
      },
      "name" : "Logical model - FR LM Immunisation",
      "description" : "Vaccination",
      "exampleBoolean" : false,
      "groupingId" : "common-models"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-immunisations.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-immunisations"
      },
      "name" : "Logical model - FR LM Immunisations",
      "description" : "Section Vaccinations",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-informant.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-informant"
      },
      "name" : "Logical model - FR LM Informant",
      "description" : "Informant (personne ayant fourni des informations utiles à la production du document : professionnel, structure, patient/usager, autre), personne de confiance, personne à prévenir en cas d'urgence, aidant, aidé.",
      "exampleBoolean" : false,
      "groupingId" : "header-models"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-intended-recipient.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-intended-recipient"
      },
      "name" : "Logical model - FR LM Intended Recipient",
      "description" : "Personne déclarée comme destinataire prévu du document.\n- Attention : Cet élément ne contient que le(s) destinataire(s) initialement prévu(s) à la création du document. Rien ne permet par la suite, de certifier que le document a réellement été envoyé à ce(s) destinataire(s).\n Par ailleurs, il ne faut pas créer de nouvelle version du document si on souhaite l'envoyer à d'autres destinataires.",
      "exampleBoolean" : false,
      "groupingId" : "header-models"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-legal-authentication.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-legal-authentication"
      },
      "name" : "Logical model - FR LM Legal Authentication",
      "description" : "Représente le responsable du document, qui est : \n - soit le professionnel qui prend la responsabilité du document produit par un lui-même ou un autre professionnel. \n - soit le professionnel qui prend la responsabilité du document produit par un système de structure (ES, …). \n - soit le patient/usager responsable du document d'expression personnelle \n - soit le SNR responsable du document produit via ce SNR. \n - Soit le Dossier Pharmaceutique (DP) responsable des documents qu'il produit",
      "exampleBoolean" : false,
      "groupingId" : "header-models"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-location.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-location"
      },
      "name" : "Logical model - FR LM Location",
      "description" : "Lieu",
      "exampleBoolean" : false,
      "groupingId" : "header-models"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-medical-device-prescriptions.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-medical-device-prescriptions"
      },
      "name" : "Logical Model - FR LM Medical Device Prescriptions",
      "description" : "Section Prescription de dispositifs médicaux",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-medical-devices-and-implants.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-medical-devices-and-implants"
      },
      "name" : "Logical Model - FR LM Medical Devices and Implants",
      "description" : "Section Dispositifs Medicaux",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-medication.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-medication"
      },
      "name" : "Logical model - FR LM Medication",
      "description" : "Produit de santé",
      "exampleBoolean" : false,
      "groupingId" : "common-models"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-medication-dispensations.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-medication-dispensations"
      },
      "name" : "Logical model - FR LM Medication Dispensations",
      "description" : "Section Dispensation médicaments",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-medication-dispense.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-medication-dispense"
      },
      "name" : "Logical model - FR LM Medication Dispense",
      "description" : "Traitement dispense",
      "exampleBoolean" : false,
      "groupingId" : "common-models"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-prescription-item.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-prescription-item"
      },
      "name" : "Logical model - FR LM Medication Prescription",
      "description" : "Traitement prescrit",
      "exampleBoolean" : false,
      "groupingId" : "common-models"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-medication-summary.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-medication-summary"
      },
      "name" : "Logical model - FR LM Medication Summary",
      "description" : "Section Traitements",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-FRLMMedicationUse.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/FRLMMedicationUse"
      },
      "name" : "Logical model - FR LM Medication Use",
      "description" : "Déclaration de l'utilisation d'un médicament, faisant partie d'une synthèse des traitements médicamenteux du patient.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-micro-organism-search.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-micro-organism-search"
      },
      "name" : "Logical model - FR LM Micro Organism Search",
      "description" : "Recherche de micro organismes",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-multidrug-resistant-microorganism-identification.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-multidrug-resistant-microorganism-identification"
      },
      "name" : "Logical model - FR LM Multidrug Resistant Microorganism Identification",
      "description" : "Identification de micro-organismes multirésistants",
      "exampleBoolean" : false,
      "groupingId" : "common-models"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-note.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-note"
      },
      "name" : "Logical model - FR LM Note",
      "description" : "Section Commentaire (non-codé)",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-observation.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-observation"
      },
      "name" : "Logical model - FR LM Observation",
      "description" : "Résultat d'une observation réalisée sur le patient ou un dispositif médical.",
      "exampleBoolean" : false,
      "groupingId" : "common-models"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-observation-vital-sign.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-observation-vital-sign"
      },
      "name" : "Logical model - FR LM Observation Vital Sign",
      "description" : "Signe vital observé",
      "exampleBoolean" : false,
      "groupingId" : "common-models"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-observation-media.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-observation-media"
      },
      "name" : "Logical model - FR LM ObservationMedia",
      "description" : "Image illustrative.",
      "exampleBoolean" : false,
      "groupingId" : "common-models"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-observation-results.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-observation-results"
      },
      "name" : "Logical model - FR LM ObservationResults",
      "description" : "Section Résultats",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-order.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-order"
      },
      "name" : "Logical model - FR LM Order",
      "description" : "Association to an order that is the origin of the act resulting in the document.",
      "exampleBoolean" : false,
      "groupingId" : "header-models"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-order-information.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-order-information"
      },
      "name" : "Logical model - FR LM Order Information",
      "description" : "Section Demande d'examen d'imagerie",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-organisation.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-organisation"
      },
      "name" : "Logical model - FR LM Organisation",
      "description" : "Une structure (organisation) pour les professionnels de santé.",
      "exampleBoolean" : false,
      "groupingId" : "header-models"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-participant.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-participant"
      },
      "name" : "Logical model - FR LM Participant",
      "description" : "Personne/Structure impliquée dans les évènements décrits par le document qui n'a pas été mentionné ailleurs.",
      "exampleBoolean" : false,
      "groupingId" : "header-models"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-patient.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-patient"
      },
      "name" : "Logical model - FR LM Patient",
      "description" : "Patient/Usager concerné par le document.",
      "exampleBoolean" : false,
      "groupingId" : "header-models"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-patient-education.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-patient-education"
      },
      "name" : "Logical model - FR LM Patient Education",
      "description" : "Section Education du patient",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-patient-story.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-patient-story"
      },
      "name" : "Logical model - FR LM Patient Story",
      "description" : "Récit du patient",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-patient-transfer.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-patient-transfer"
      },
      "name" : "Logical model - FR LM Patient Transfer.",
      "description" : "Transfert du patient",
      "exampleBoolean" : false,
      "groupingId" : "common-models"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-predictable-adverse-drug-reaction.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-predictable-adverse-drug-reaction"
      },
      "name" : "Logical model - FR LM Predictable Adverse Drug Reaction",
      "description" : "Section Effets indesirables",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-prescription-entree.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-prescription-entree"
      },
      "name" : "Logical model - FR LM Prescription",
      "description" : "Prescription",
      "exampleBoolean" : false,
      "groupingId" : "common-models"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-presented-form.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-presented-form"
      },
      "name" : "Logical model - FR LM Presented Form",
      "description" : "Section Document PDF-copie",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-problems.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-problems"
      },
      "name" : "Logical model - FR LM Problems",
      "description" : "Section Problems",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-procedures.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-procedures"
      },
      "name" : "logical model - FR LM Procedures",
      "description" : "Section Historique des actes",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-qr-code.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-qr-code"
      },
      "name" : "Logical model - FR LM QR Code",
      "description" : "Section Codes à barres",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-quantity-exposure.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-quantity-exposure"
      },
      "name" : "Logical model - FR LM Quantity Exposure",
      "description" : "Quantité exposition",
      "exampleBoolean" : false,
      "groupingId" : "common-models"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-reason-for-referral.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-reason-for-referral"
      },
      "name" : "Logical model - FR LM Reason for referral",
      "description" : "Section Raison de la recommandation",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-recommendation.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-recommendation"
      },
      "name" : "Logical model - FR LM Recommendation",
      "description" : "Section Recommandation",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-related-person.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-related-person"
      },
      "name" : "Logical model - FR LM Related Person",
      "description" : "Related Person",
      "exampleBoolean" : false,
      "groupingId" : "header-models"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-resultats-examens-biologie-medicale.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-resultats-examens-biologie-medicale"
      },
      "name" : "Logical model - FR LM Resultats d'examens de biologie medicale",
      "description" : "Resultats d'examens de biologie medicale",
      "exampleBoolean" : false,
      "groupingId" : "common-models"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-section.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-section"
      },
      "name" : "Logical model - FR LM Section",
      "description" : "Section",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-series.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-series"
      },
      "name" : "Logical model - FR LM Series",
      "description" : "Séries d'actes d'imagerie",
      "exampleBoolean" : false,
      "groupingId" : "common-models"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-service-request.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-service-request"
      },
      "name" : "Logical model - FR LM Service Request",
      "description" : "Demande d'examen ou de suivi / Objectif à atteindre",
      "exampleBoolean" : false,
      "groupingId" : "common-models"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-social-history.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-social-history"
      },
      "name" : "Logical model - FR LM SocialHistory",
      "description" : "Section Habitus et modes de vie",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-sop-instance.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-sop-instance"
      },
      "name" : "Logical model - FR LM SOP Instance",
      "description" : "SOP Instance",
      "exampleBoolean" : false,
      "groupingId" : "common-models"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-specimen.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-specimen"
      },
      "name" : "Logical model - FR LM Specimen",
      "description" : "Prélèvement",
      "exampleBoolean" : false,
      "groupingId" : "common-models"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-supporting-information.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-supporting-information"
      },
      "name" : "Logical model - FR LM Supporting Information",
      "description" : "Section Informations Cliniques",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-transfusion-accidents.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-transfusion-accidents"
      },
      "name" : "Logical model - FR LM Transfusion accidents",
      "description" : "Accidents transfusionnels",
      "exampleBoolean" : false,
      "groupingId" : "common-models"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-transfusion-de-produits-sanguins.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-transfusion-de-produits-sanguins"
      },
      "name" : "Logical model - FR LM Transfusion de produits sanguins",
      "description" : "Transfusion de produits sanguins",
      "exampleBoolean" : false,
      "groupingId" : "common-models"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-travel-history.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-travel-history"
      },
      "name" : "Logical model - FR LM TravelHistory",
      "description" : "Historique des voyages.",
      "exampleBoolean" : false,
      "groupingId" : "common-models"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-vital-signs.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-vital-signs"
      },
      "name" : "Logical model - FR LM Vital Signs",
      "description" : "Section Signes vitaux",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-laboratory-observation.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-laboratory-observation"
      },
      "name" : "Logical model - Laboratory Observation",
      "description" : "Résultats d'examen de biologie médicale",
      "exampleBoolean" : false,
      "groupingId" : "common-models"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-dosageInstructions.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-dosageInstructions"
      },
      "name" : "Logical model- FR LM Dosage Instructions",
      "description" : "Posologie",
      "exampleBoolean" : false,
      "groupingId" : "common-models"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-functional-status.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-functional-status"
      },
      "name" : "logical model- FR LM Functional Status",
      "description" : "Section Statut fonctionnel",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-medication-administration.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-medication-administration"
      },
      "name" : "Logical model- FR LM Medication Administration\t",
      "description" : "Traitement",
      "exampleBoolean" : false,
      "groupingId" : "common-models"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-observation-social-history.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-observation-social-history"
      },
      "name" : "Logical model- FR LM Observation Social History",
      "description" : "Habitus Mode de vie",
      "exampleBoolean" : false,
      "groupingId" : "common-models"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-pregnancy-history.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-pregnancy-history"
      },
      "name" : "Logical model- FR LM Pregnancy History",
      "description" : "Historique de la grossesse",
      "exampleBoolean" : false,
      "groupingId" : "common-models"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-pregnancy-observation.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-pregnancy-observation"
      },
      "name" : "Logical model- FR LM Pregnancy Observation",
      "description" : "Observation sur la grossesse",
      "exampleBoolean" : false,
      "groupingId" : "common-models"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-pregnancy-status.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-pregnancy-status"
      },
      "name" : "Logical model- FR LM Pregnancy Status",
      "description" : "Statut de grossesse",
      "exampleBoolean" : false,
      "groupingId" : "common-models"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-procedure.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-procedure"
      },
      "name" : "Logical model- FR LM Procedure",
      "description" : "Acte",
      "exampleBoolean" : false,
      "groupingId" : "common-models"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRSectionImagingAddendumLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRSectionImagingAddendumLMCDAFHIR"
      },
      "name" : "Mapping FRLMAddendum → FRCDAdicomAddendum → FRCompositionDocument.section:Addendum",
      "description" : "Mapping des éléments du modèle métier FRLMAddendum vers la section CDA FRCDADicomAddendum puis vers le profil FHIR FRCompositionDocument.section:Addendum.",
      "exampleBoolean" : false,
      "groupingId" : "section-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRAdvanceDirectiveLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRAdvanceDirectiveLMCDAFHIR"
      },
      "name" : "Mapping FRLMAdvanceDirective → FRCDADirectiveAnticipee / FRLMAdvanceDirective → FRAdvanceDirectiveDocument",
      "description" : "Mapping des éléments du modèle métier FRLMAdvanceDirective vers le profil CDA FRCDADirectiveAnticipee, puis vers le profil FHIR FRAdvanceDirectiveDocument.",
      "exampleBoolean" : false,
      "groupingId" : "common-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRAdverseDrugReactionLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRAdverseDrugReactionLMCDAFHIR"
      },
      "name" : "Mapping FRLMAdverseDrugReaction → FRCDAEffetIndesirable / FRLMAdverseDrugReaction → FRAdverseEventDocument",
      "description" : "Mapping des éléments du modèle métier FRLMAdverseDrugReaction vers le profil CDA FRCDAEffetIndesirable, puis vers le profil FHIR FRAdverseEventDocument.",
      "exampleBoolean" : false,
      "groupingId" : "common-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRAllergyIntoleranceLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRAllergyIntoleranceLMCDAFHIR"
      },
      "name" : "Mapping FRLMAllergyIntolerance → FRCDAAllergieOuHypersensibilite / FRLMAllergyIntolerance → FRAllergyIntoleranceDocument",
      "description" : "Mapping des éléments du modèle métier FRLMAllergyIntolerance vers le profil CDA FRCDAAllergieOuHypersensibilite, puis vers le profil FHIR FRAllergyIntoleranceDocument.",
      "exampleBoolean" : false,
      "groupingId" : "common-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRAttachmentLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRAttachmentLMCDAFHIR"
      },
      "name" : "Mapping FRLMAttachment → FRCDADocumentAttache → FRDocumentReferenceDocument",
      "description" : "Mapping des éléments du modèle métier FRLMAttachment vers le profil CDA FRCDADocumentAttache, puis vers le profil FHIR FRDocumentReferenceDocument.",
      "exampleBoolean" : false,
      "groupingId" : "common-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRLaboratoryBatteryResultsLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRLaboratoryBatteryResultsLMCDAFHIR"
      },
      "name" : "Mapping FRLMBatterieExamensBiologieMedicale → FRCDABatterieExamensDeBiologieMedicale → FRObservationLaboratoryReportResultsDocument",
      "description" : "Mapping des éléments du modèle métier FRLMBatterieExamensBiologieMedicale vers le profil CDA FRCDABatterieExamensDeBiologieMedicale, puis vers le profil FHIR FRObservationLaboratoryReportResultsDocument.",
      "exampleBoolean" : false,
      "groupingId" : "common-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRCarePlanLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRCarePlanLMCDAFHIR"
      },
      "name" : "Mapping FRLMCarePlan → FRCDAReferenceItemPlanTraitement / FRLMCarePlan → FRCarePlanDocument",
      "description" : "Mapping des éléments du modèle métier FRLMCarePlan vers le profil CDA FRCDAReferenceItemPlanTraitement (équivalent CDA le plus proche), puis vers le profil FHIR FRCarePlanDocument.",
      "exampleBoolean" : false,
      "groupingId" : "common-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRSectionImagingComparisonLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRSectionImagingComparisonLMCDAFHIR"
      },
      "name" : "Mapping FRLMComparaisonExamensImagerie → FRCDADICOMExamenComparatif → FRCompositionDocument.section:Comparison",
      "description" : "Mapping des éléments du modèle métier FRLMComparaisonExamensImagerie vers le profil CDA FRCDADICOMExamenComparatif, puis vers la section Comparison du profil FHIR FRCompositionDocument.",
      "exampleBoolean" : false,
      "groupingId" : "section-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRSectionImagingComplicationsLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRSectionImagingComplicationsLMCDAFHIR"
      },
      "name" : "Mapping FRLMComplicationsActe → FRCDADICOMComplications → FRProcedureImagingDocument.complication.text",
      "description" : "Mapping des éléments du modèle métier FRLMComplicationsActe vers la section CDA FRCDADICOMComplications, puis vers le champ 'complication.text' du profil FHIR FRProcedureImagingDocument.",
      "exampleBoolean" : false,
      "groupingId" : "section-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRSectionImagingConclusionLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRSectionImagingConclusionLMCDAFHIR"
      },
      "name" : "Mapping FRLMConclusionExamenImagerie → FRCDADICOMConclusion → FRDiagnosticReportImagingDocument.conclusion",
      "description" : "Mapping des éléments du modèle métier FRLMConclusionExamenImagerie vers la section CDA FRCDADICOMConclusion, puis vers le champ 'conclusion' du profil FHIR FRDiagnosticReportImagingDocument.",
      "exampleBoolean" : false,
      "groupingId" : "section-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRConditionLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRConditionLMCDAFHIR"
      },
      "name" : "Mapping FRLMCondition → FRCDAProbleme / FRLMCondition → FRConditionDocument",
      "description" : "Mapping des éléments du modèle métier FRLMCondition vers le profil CDA FRCDAProbleme, puis vers le profil FHIR FRConditionDocument.",
      "exampleBoolean" : false,
      "groupingId" : "common-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRSectionLaboratoryChapterLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRSectionLaboratoryChapterLMCDAFHIR"
      },
      "name" : "Mapping FRLMCRBIOChapitre → FRCDACRBIOChapitre → FRCompositionDocument.section",
      "description" : "Mapping des éléments du modèle métier FRLMCRBIOChapitre vers la section CDA FRCDACRBIOChapitre, puis vers le profil FHIR FRCompositionDocument.section.",
      "exampleBoolean" : false,
      "groupingId" : "section-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRSectionLaboratorySubChapterLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRSectionLaboratorySubChapterLMCDAFHIR"
      },
      "name" : "Mapping FRLMCRBIOSousChapitre → FRCDACRBIOSousChapitre → FRCompositionDocument.section:avec-sous-sections.section",
      "description" : "Mapping des éléments du modèle métier FRLMCRBIOSousChapitre vers la section CDA FRCDACRBIOSousChapitre, puis vers le profil FHIR FRCompositionDocument.section:avec-sous-sections.section.",
      "exampleBoolean" : false,
      "groupingId" : "section-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRSectionImagingServiceRequestLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRSectionImagingServiceRequestLMCDAFHIR"
      },
      "name" : "Mapping FRLMDemandeExamenImagerie → FRCDADICOMDemandeExamen → FRServiceRequestDocument",
      "description" : "Mapping des éléments du modèle métier FRLMDemandeExamenImagerie vers la section CDA FRCDADICOMDemandeExamen puis vers le profil FHIR FRCompositionDocument.section:serviceRequest.",
      "exampleBoolean" : false,
      "groupingId" : "section-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRDeviceLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRDeviceLMCDAFHIR"
      },
      "name" : "Mapping FRLMDevice → FRCDADispositifMedical / FRLMDevice → Device",
      "description" : "Mapping des éléments du modèle métier FRLMDevice vers le profil CDA FRCDADispositifMedical, puis vers la ressource FHIR Device.",
      "exampleBoolean" : false,
      "groupingId" : "common-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRDeviceUseLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRDeviceUseLMCDAFHIR"
      },
      "name" : "Mapping FRLMDeviceUse → FRCDADispositifMedical / FRLMDeviceUse → FRDeviceUseStatementDocument",
      "description" : "Mapping des éléments du modèle métier FRLMDeviceUse vers le profil CDA FRCDADispositifMedical, puis vers le profil FHIR FRDeviceUseStatementDocument.",
      "exampleBoolean" : false,
      "groupingId" : "common-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRSectionAdvanceDirectiveLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRSectionAdvanceDirectiveLMCDAFHIR"
      },
      "name" : "Mapping FRLMDirectivesAnticipees → FRCDADirectivesAnticipees → FRAdvanceDirectiveDocument",
      "description" : "Mapping des éléments du modèle métier FRLMDirectivesAnticipees vers la section CDA FRCDADirectivesAnticipees, puis vers le profil FHIR FRAdvanceDirectiveDocument.",
      "exampleBoolean" : false,
      "groupingId" : "section-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRSectionMedicationDispenseLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRSectionMedicationDispenseLMCDAFHIR"
      },
      "name" : "Mapping FRLMDispensationMedicaments → FRCDADispensationMedicaments → FRMedicationDispenseDocument",
      "description" : "Mapping des éléments du modèle métier FRLMDispensationMedicaments vers la section CDA FRCDADispensationMedicaments, puis vers la section FHIR FRCompositionDocument.section:medication-dispense.",
      "exampleBoolean" : false,
      "groupingId" : "section-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRSectionMedicalDeviceLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRSectionMedicalDeviceLMCDAFHIR"
      },
      "name" : "Mapping FRLMDispositifsMedicaux → FRCDADispositifsMedicaux → FRCompositionDocument.section:medicalDevice",
      "description" : "Mapping des éléments du modèle métier FRLMDispositifsMedicaux vers la section CDA FRCDADispositifsMedicaux, puis vers la section FHIR FRCompositionDocument.section:medicalDevice.",
      "exampleBoolean" : false,
      "groupingId" : "section-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRSectionPDFDocumentCopyLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRSectionPDFDocumentCopyLMCDAFHIR"
      },
      "name" : "Mapping FRLMDocumentPDFCopie → FRCDADocumentPDFCopie → FRCompositionDocument.section:pdfDocumentCopy",
      "description" : "Mapping des éléments du modèle métier FRLMDocumentPDFCopie vers la section CDA FRCDADocumentPDFCopie, puis vers la section FHIR FRCompositionDocument.section:pdfDocumentCopy.",
      "exampleBoolean" : false,
      "groupingId" : "section-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRSectionAddedDocumentsLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRSectionAddedDocumentsLMCDAFHIR"
      },
      "name" : "Mapping FRLMDocumentsAjoutes → FRCDADocumentsAjoutes → FRCompositionDocument.section:addedDocuments",
      "description" : "Mapping des éléments du modèle métier FRLMDocumentsAjoutes vers la section CDA FRCDADocumentsAjoutes, puis vers la section FHIR FRCompositionDocument.section:addedDocuments.",
      "exampleBoolean" : false,
      "groupingId" : "section-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRSectionPatientEducationLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRSectionPatientEducationLMCDAFHIR"
      },
      "name" : "Mapping FRLMEducationPatient → FRCDAEducationDuPatient → FRCompositionDocument.section:patientEducation",
      "description" : "Mapping des éléments du modèle métier FRLMEducationPatient vers la section CDA FRCDAEducationDuPatient, puis vers la section FHIR FRCompositionDocument.section:patientEducation.",
      "exampleBoolean" : false,
      "groupingId" : "section-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRSectionAdverseEventLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRSectionAdverseEventLMCDAFHIR"
      },
      "name" : "Mapping FRLMEffetsIndesirables → FRCDAEffetsIndesirables → FRCompositionDocument.section:adverseEvent",
      "description" : "Mapping des éléments du modèle métier FRLMEffetsIndesirables vers la section CDA FRCDAEffetsIndesirables, puis vers la section FHIR FRCompositionDocument.section:adverseEvent.",
      "exampleBoolean" : false,
      "groupingId" : "section-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FREncounterLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FREncounterLMCDAFHIR"
      },
      "name" : "Mapping FRLMEncounter → FRCDARencontre / FRLMEncounter → FREncounterDocument",
      "description" : "Mapping des éléments du modèle métier FRLMEncounter vers le profil CDA FRCDARencontre, puis vers le profil FHIR FREncounterDocument.",
      "exampleBoolean" : false,
      "groupingId" : "common-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRSectionExposureRadiationLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRSectionExposureRadiationLMCDAFHIR"
      },
      "name" : "Mapping FRLMExpositionRadiations → FRCDADICOMExpositionAuxRadiations → FRCompositionDocument.section:exposureRadiation",
      "description" : "Mapping des éléments du modèle métier FRLMExpositionRadiations vers la section CDA FRCDADICOMExpositionAuxRadiations, puis vers la section FHIR FRCompositionDocument.section:exposureRadiation.",
      "exampleBoolean" : false,
      "groupingId" : "section-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRSectionImagingRadiationExposureLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRSectionImagingRadiationExposureLMCDAFHIR"
      },
      "name" : "Mapping FRLMExpositionRadiations → FRCDADICOMExpositionAuxRadiations → FRCompositionDocument.section:radiationExposure",
      "description" : "Mapping des éléments du modèle métier FRLMExpositionRadiations vers la section CDA FRCDADICOMExpositionAuxRadiations puis vers le profil FHIR FRCompositionDocument.section:radiationExposure.",
      "exampleBoolean" : false,
      "groupingId" : "section-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRSectionUncodedOccupationalRiskFactorsLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRSectionUncodedOccupationalRiskFactorsLMCDAFHIR"
      },
      "name" : "Mapping FRLMFacteursDeRisqueProfessionnelsNonCode → FRCDAFacteursDeRisqueProfessionnelsNonCode → FRCompositionDocument.section:uncodedOccupationalRiskFactors",
      "description" : "Mapping des éléments du modèle métier FRLMFacteursDeRisqueProfessionnelsNonCode vers la section CDA FRCDAFacteursDeRisqueProfessionnelsNonCode, puis vers la section FHIR FRCompositionDocument.section:uncodedOccupationalRiskFactors.",
      "exampleBoolean" : false,
      "groupingId" : "section-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRFamilyMemberHistoryLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRFamilyMemberHistoryLMCDAFHIR"
      },
      "name" : "Mapping FRLMFamilyMemberHistory → FRCDAAntecedentsFamiliaux / FRLMFamilyMemberHistory → FRFamilyMemberHistoryDocument",
      "description" : "Mapping des éléments du modèle métier FRLMFamilyMemberHistory vers le profil CDA FRCDAAntecedentsFamiliaux, puis vers le profil FHIR FRFamilyMemberHistoryDocument.",
      "exampleBoolean" : false,
      "groupingId" : "common-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRSectionPhysicalFunctionsLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRSectionPhysicalFunctionsLMCDAFHIR"
      },
      "name" : "Mapping FRLMFonctionsPhysiques → FRCDAFonctionsPhysiques → FRCompositionDocument.section:PhysicalFunctions",
      "description" : "Mapping des éléments du modèle métier FRLMFonctionsPhysiques vers la section CDA FRCDAFonctionsPhysiques, puis vers le profil FHIR FRCompositionDocument.section:PhysicalFunctions.",
      "exampleBoolean" : false,
      "groupingId" : "section-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRSectionSocialHistoryLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRSectionSocialHistoryLMCDAFHIR"
      },
      "name" : "Mapping FRLMHabitusModeDeVie → FRCDAHabitusModeDeVieSection → FRCompositionDocument.section:socialHistory",
      "description" : "Mapping des éléments du modèle métier FRLMHabitusModeDeVie vers la section CDA FRCDAHabitusModeDeVieSection, puis vers le profil FHIR FRCompositionDocument.section:socialHistory.",
      "exampleBoolean" : false,
      "groupingId" : "section-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRSectionHistoryActsLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRSectionHistoryActsLMCDAFHIR"
      },
      "name" : "Mapping FRLMHistoriqueDesActes → FRCDAHistoriqueDesActes → FRCompositionDocument.section:historyActs",
      "description" : "Mapping des éléments du modèle métier FRLMHistoriqueDesActes vers la section CDA FRCDAHistoriqueDesActes, puis vers la section FHIR FRCompositionDocument.section:historyActs.",
      "exampleBoolean" : false,
      "groupingId" : "section-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRSectionPregnancyHistoryLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRSectionPregnancyHistoryLMCDAFHIR"
      },
      "name" : "Mapping FRLMHistoriqueDesGrossesses → FRCDAHistoriqueDesGrossesses → FRCompositionDocument.section:pregnancyHistory",
      "description" : "Mapping des éléments du modèle métier FRLMHistoriqueDesGrossesses vers la section CDA FRCDAHistoriqueDesGrossesses, puis vers la section FHIR FRCompositionDocument.section:pregnancyHistory.",
      "exampleBoolean" : false,
      "groupingId" : "section-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRImagingStudyLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRImagingStudyLMCDAFHIR"
      },
      "name" : "Mapping FRLMImagingStudy → FRCDADICOMExamenImagerie / FRLMImagingStudy → FRImagingStudyDocument",
      "description" : "Mapping des éléments du modèle métier FRLMImagingStudy vers le profil CDA FRCDADICOMExamenImagerie, puis vers le profil FHIR FRImagingStudyDocument.",
      "exampleBoolean" : false,
      "groupingId" : "common-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRImmunisationLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRImmunisationLMCDAFHIR"
      },
      "name" : "Mapping FRLMImmunisation → FRCDAVaccination / FRLMImmunisation → FRImmunizationDocument",
      "description" : "Mapping des éléments du modèle métier FRLMImmunisation vers le profil CDA FRCDAVaccination, puis vers le profil FHIR FRImmunizationDocument.",
      "exampleBoolean" : false,
      "groupingId" : "common-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRSectionImagingClinicalInformationLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRSectionImagingClinicalInformationLMCDAFHIR"
      },
      "name" : "Mapping FRLMInformationsCliniques → FRCDADICOMHistoriqueMedical → FRCompositionDocument.section:History (Observation / FRConditionDocument/ FRObservationPregnancyDocument / FRObservationContraIndicationsImagingDocument / FRDeviceAuteurDocument / FRMedicationAdministrationDocument)",
      "description" : "Mapping des éléments du modèle métier FRLMInformationsCliniques vers la section CDA FRCDADICOMHistoriqueMedical puis vers les profils FHIR Observation, FRConditionDocument, FRObservationPregnancyDocument, FRObservationContraIndicationsImagingDocument, FRDeviceAuteurDocument et FRMedicationAdministrationDocument.",
      "exampleBoolean" : false,
      "groupingId" : "section-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRLaboratoryIsolateResultsLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRLaboratoryIsolateResultsLMCDAFHIR"
      },
      "name" : "Mapping FRLMIsolatMicrobiologique → FRCDAIsolatMicrobiologique → FRObservationLaboratoryReportResultsDocument",
      "description" : "Mapping des éléments du modèle métier FRLMIsolatMicrobiologique vers le profil CDA FRCDAIsolatMicrobiologique, puis vers le profil FHIR FRObservationLaboratoryReportResultsDocument.",
      "exampleBoolean" : false,
      "groupingId" : "common-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRMedicationLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRMedicationLMCDAFHIR"
      },
      "name" : "Mapping FRLMMedication → FRCDAProduitDeSante / FRLMMedication → FRMedicationDocument",
      "description" : "Mapping des éléments du modèle métier FRLMMedication vers le profil CDA FRCDAProduitDeSante (Groupe 1), et vers le profil FHIR FRMedicationDocument (Groupe 2).",
      "exampleBoolean" : false,
      "groupingId" : "common-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRImagingMedicationAministrationLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRImagingMedicationAministrationLMCDAFHIR"
      },
      "name" : "Mapping FRLMMedicationAdministration -> FRCDADICOMAdministrationProduitDeSante / FRLMMedicationAdministration -> FRMedicationAdministrationDocument",
      "description" : "Mapping des elements du modele metier FRLMMedicationAdministration vers le profil CDA FRCDADICOMAdministrationProduitDeSante, puis vers le profil FHIR FRMedicationAdministrationDocument.",
      "exampleBoolean" : false,
      "groupingId" : "common-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRMedicationAdministrationLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRMedicationAdministrationLMCDAFHIR"
      },
      "name" : "Mapping FRLMMedicationAdministration → FRCDATraitement / FRLMMedicationAdministration → FRMedicationAdministrationDocument",
      "description" : "Mapping des éléments du modèle métier FRLMMedicationAdministration vers le profil CDA FRCDATraitement (Groupe 1), et vers le profil FHIR FRMedicationAdministrationDocument (Groupe 2).",
      "exampleBoolean" : false,
      "groupingId" : "common-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRMedicationDispenseLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRMedicationDispenseLMCDAFHIR"
      },
      "name" : "Mapping FRLMMedicationDispense → FRCDATraitementDispense / FRLMMedicationDispense → FRMedicationDispenseDocument",
      "description" : "Mapping des éléments du modèle métier FRLMMedicationDispense vers le profil CDA FRCDATraitementDispense (Groupe 1), et vers le profil FHIR FRMedicationDispenseDocument (Groupe 2).",
      "exampleBoolean" : false,
      "groupingId" : "common-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRMedicationStatementLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRMedicationStatementLMCDAFHIR"
      },
      "name" : "Mapping FRLMMedicationUse → FRCDATraitement / FRLMMedicationUse → FRMedicationStatementDocument",
      "description" : "Mapping des éléments du modèle métier FRLMMedicationUse vers la sous-entrée CDA FRCDATraitement puis vers le profil FHIR FRMedicationStatementDocument.",
      "exampleBoolean" : false,
      "groupingId" : "common-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRObservationMicroorganismDetectionLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRObservationMicroorganismDetectionLMCDAFHIR"
      },
      "name" : "Mapping FRLMMicroOrganismSearch → FRCDARechercheDeMicroOrganismes / FRLMMicroOrganismSearch → FRObservationMicroorganismDetectionDocument",
      "description" : "Mapping des éléments du modèle métier FRLMMicroOrganismSearch vers le profil CDA FRCDARechercheDeMicroOrganismes, puis vers le profil FHIR FRObservationMicroorganismDetectionDocument.",
      "exampleBoolean" : false,
      "groupingId" : "common-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRObservationMultiresistantMicroorganismsIdentificationLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRObservationMultiresistantMicroorganismsIdentificationLMCDAFHIR"
      },
      "name" : "Mapping FRLMMultidrugResistantMicroorganismIdentification → FRCDAIdentificationMicroOrganismesMultiresistants / FRLMMultidrugResistantMicroorganismIdentification → FRObservationMultiresistantMicroorganismsIdentificationDocument",
      "description" : "Mapping des éléments du modèle métier FRLMMultidrugResistantMicroorganismIdentification vers le profil CDA FRCDAIdentificationMicroOrganismesMultiresistants, puis vers le profil FHIR FRObservationMultiresistantMicroorganismsIdentificationDocument.",
      "exampleBoolean" : false,
      "groupingId" : "common-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRSectionImagingObjectCatalogLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRSectionImagingObjectCatalogLMCDAFHIR"
      },
      "name" : "Mapping FRLMObjectCatalog → FRCDADICOMObjectCatalog → FRCompositionDocument.section:imagingStudy",
      "description" : "Mapping des éléments du modèle métier FRLMObjectCatalog vers la section CDA FRCDADICOMObjectCatalog, puis vers la section FHIR FRCompositionDocument.section:imagingStudy.",
      "exampleBoolean" : false,
      "groupingId" : "section-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRObservationLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRObservationLMCDAFHIR"
      },
      "name" : "Mapping FRLMObservation -> FRCDASimpleObservation / FRLMObservation -> Observation",
      "description" : "Mapping des éléments du modele metier FRLMObservation vers le profil CDA FRCDASimpleObservation, puis vers le profil FHIR Observation.",
      "exampleBoolean" : false,
      "groupingId" : "common-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRObservationResultLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRObservationResultLMCDAFHIR"
      },
      "name" : "Mapping FRLMObservation → FRCDAResultat / FRLMObservation → FRObservationResultDocument",
      "description" : "Mapping des éléments du modèle métier FRLMObservation vers le profil CDA FRCDAResultat, puis vers le profil FHIR FRObservationResultDocument.",
      "exampleBoolean" : false,
      "groupingId" : "common-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRObservationAssessmentLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRObservationAssessmentLMCDAFHIR"
      },
      "name" : "Mapping FRLMObservationAssessment → FRCDAEvaluation / FRLMObservationAssessment → FRObservationAssessmentDocument",
      "description" : "Mapping des éléments du modèle métier FRLMObservationAssessment vers le profil CDA FRCDAEvaluation, puis vers le profil FHIR FRObservationAssessmentDocument.",
      "exampleBoolean" : false,
      "groupingId" : "common-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRMediaLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRMediaLMCDAFHIR"
      },
      "name" : "Mapping FRLMObservationMedia → FRCDAImageIllustrative / FRLMObservationMedia → FRMediaDocument",
      "description" : "Mapping des éléments du modèle métier FRLMObservationMedia vers le profil CDA FRCDAImageIllustrative, puis vers le profil FHIR FRMediaDocument.",
      "exampleBoolean" : false,
      "groupingId" : "common-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRObservationSocialHistoryLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRObservationSocialHistoryLMCDAFHIR"
      },
      "name" : "Mapping FRLMObservationSocialHistory → FRCDAHabitusModeDeVie → FRObservationSocialHistoryDocument",
      "description" : "Mapping des éléments du modèle métier FRLMObservationSocialHistory vers le profil CDA FRCDAHabitusModeDeVie, puis vers le profil FHIR FRObservationSocialHistoryDocument.",
      "exampleBoolean" : false,
      "groupingId" : "common-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRObservationVitalSignsLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRObservationVitalSignsLMCDAFHIR"
      },
      "name" : "Mapping FRLMObservationVitalSign → FRCDASigneVitalObserve / FRLMObservationVitalSign → FRObservationVitalSignsDocument",
      "description" : "Mapping des éléments du modèle métier FRLMObservationVitalSign vers le profil CDA FRCDASigneVitalObserve, puis vers le profil FHIR FRObservationVitalSignsDocument.",
      "exampleBoolean" : false,
      "groupingId" : "common-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRParticipantCorpsLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRParticipantCorpsLMCDAFHIR"
      },
      "name" : "Mapping FRLMParticipant -> FRCDAParticipant / FRLMParticipant -> FRActorExtension",
      "description" : "Mapping des éléments du modèle métier FRLMParticipant vers le profil CDA FRCDAParticipant, puis vers l'extension FHIR FRActorExtension.",
      "exampleBoolean" : false,
      "groupingId" : "common-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRSectionCarePlanLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRSectionCarePlanLMCDAFHIR"
      },
      "name" : "Mapping FRLMPlanSoins → FRCDAPlanDeSoins → FRCompositionDocument.section:planOfCare",
      "description" : "Mapping des éléments du modèle métier FRLMPlanSoins vers la section CDA FRCDAPlanDeSoins, puis vers la section FHIR FRCompositionDocument.section:planOfCare.",
      "exampleBoolean" : false,
      "groupingId" : "section-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRSectionUncodedPointsOfVigilanceLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRSectionUncodedPointsOfVigilanceLMCDAFHIR"
      },
      "name" : "Mapping FRLMPointsDeVigilancesNonCode → FRCDAPointsDeVigilancesNonCode → FRCompositionDocument.section:uncodedPointsOfVigilance",
      "description" : "Mapping des éléments du modèle métier FRLMPointsDeVigilancesNonCode vers la section CDA FRCDAPointsDeVigilancesNonCode, puis vers la section FHIR FRCompositionDocument.section:uncodedPointsOfVigilance.",
      "exampleBoolean" : false,
      "groupingId" : "section-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRPregnancyHistoryLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRPregnancyHistoryLMCDAFHIR"
      },
      "name" : "Mapping FRLMPregnancyHistory → FRCDAHistoriqueDeLaGrossesse / FRLMPregnancyHistory → FRPregnancyHistoryDocument",
      "description" : "Mapping des éléments du modèle métier FRLMPregnancyHistory vers le profil CDA FRCDAHistoriqueDeLaGrossesse, puis vers le profil FHIR FRPregnancyHistoryDocument.",
      "exampleBoolean" : false,
      "groupingId" : "common-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRObservationPregnancyLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRObservationPregnancyLMCDAFHIR"
      },
      "name" : "Mapping FRLMPregnancyObservation → FRCDAObservationSurLaGrossesse / FRLMPregnancyObservation → FRObservationPregnancyDocument",
      "description" : "Mapping des éléments du modèle métier FRLMPregnancyObservation vers le profil CDA FRCDAObservationSurLaGrossesse, puis vers le profil FHIR FRObservationPregnancyDocument.",
      "exampleBoolean" : false,
      "groupingId" : "common-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRSectionPrescriptionOfMedicalDevicesLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRSectionPrescriptionOfMedicalDevicesLMCDAFHIR"
      },
      "name" : "Mapping FRLMPrescriptionDispositifsMedicaux → FRCDAPrescriptionDispositifsMedicaux → FRCompositionDocument.section:medicalDevicePrescription",
      "description" : "Mapping des éléments du modèle métier FRLMPrescriptionDispositifsMedicaux vers la section CDA FRCDAPrescriptionDispositifsMedicaux, puis vers la section FHIR FRCompositionDocument.section:medicalDevicePrescription.",
      "exampleBoolean" : false,
      "groupingId" : "section-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRMedicationRequestLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRMedicationRequestLMCDAFHIR"
      },
      "name" : "Mapping FRLMPrescriptionItem → FRCDATraitementPrescrit / FRLMPrescriptionItem → FRMedicationRequestDocument",
      "description" : "Mapping des éléments du modèle métier FRLMPrescriptionItem vers l'entrée CDA FRCDATraitementPrescrit, puis vers le profil FHIR FRMedicationRequestDocument.",
      "exampleBoolean" : false,
      "groupingId" : "common-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRSectionMedicationRequestLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRSectionMedicationRequestLMCDAFHIR"
      },
      "name" : "Mapping FRLMPrescriptionMedicaments → FRCDAPrescriptionMedicaments → FRCompositionDocument.section:medicationRequest",
      "description" : "Mapping des éléments du modèle métier FRLMPrescriptionMedicaments vers la section CDA FRCDAPrescriptionMedicaments, puis vers la section FHIR FRCompositionDocument.section:medicationRequest.",
      "exampleBoolean" : false,
      "groupingId" : "section-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRSectionActiveProblemsLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRSectionActiveProblemsLMCDAFHIR"
      },
      "name" : "Mapping FRLMProblemesActifs → FRCDAProblemesActifs → FRCompositionDocument.section:activeProblems",
      "description" : "Mapping des éléments du modèle métier FRLMProblemesActifs vers la section CDA FRCDAProblemesActifs, puis vers la section FHIR FRCompositionDocument.section:activeProblems.",
      "exampleBoolean" : false,
      "groupingId" : "section-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRProcedureLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRProcedureLMCDAFHIR"
      },
      "name" : "Mapping FRLMProcedure → FRCDAActe / FRLMProcedure → FRProcedureDocument",
      "description" : "Mapping des éléments du modèle métier FRLMProcedure vers le profil CDA FRCDAActe, puis vers le profil FHIR FRProcedureDocument.",
      "exampleBoolean" : false,
      "groupingId" : "common-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRImagingProcedureLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRImagingProcedureLMCDAFHIR"
      },
      "name" : "Mapping FRLMProcedure → FRCDADICOMTechniqueImagerie / FRLMProcedure → FRProcedureImagingDocument",
      "description" : "Mapping des éléments du modèle métier FRLMProcedure vers le profil CDA FRCDADICOMTechniqueImagerie, puis vers le profil FHIR FRProcedureImagingDocument.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRImagingQuantityExposureLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRImagingQuantityExposureLMCDAFHIR"
      },
      "name" : "Mapping FRLMQuantityExposure → FRCDADICOMQuantite / FRLMQuantityExposure → FRObservationRadiationExposureDocument.component",
      "description" : "Mapping des éléments du modèle métier FRLMQuantityExposure vers l'entrée CDA FRCDADICOMQuantite, puis vers le profil FHIR FRObservationRadiationExposureDocument.",
      "exampleBoolean" : false,
      "groupingId" : "common-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRSectionReasonForRecommendationLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRSectionReasonForRecommendationLMCDAFHIR"
      },
      "name" : "Mapping FRLMRaisonRecommandation → FRCDARaisonDeLaRecommandation → FRCompositionDocument.section:reasonForRecommendation",
      "description" : "Mapping des éléments du modèle métier FRLMRaisonRecommandation vers la section CDA FRCDARaisonDeLaRecommandation, puis vers la section FHIR FRCompositionDocument.section:reasonForRecommendation.",
      "exampleBoolean" : false,
      "groupingId" : "section-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRSectionUncodedReasonForRecommendationLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRSectionUncodedReasonForRecommendationLMCDAFHIR"
      },
      "name" : "Mapping FRLMRaisonRecommandationNonCode → FRCDARaisonDeLaRecommandationNonCode → FRCompositionDocument.section:reasonForRecommendation",
      "description" : "Mapping des éléments du modèle métier FRLMRaisonRecommandationNonCode vers la section CDA FRCDARaisonDeLaRecommandationNonCode, puis vers la section FHIR FRCompositionDocument.section:reasonForRecommendation.",
      "exampleBoolean" : false,
      "groupingId" : "section-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRLaboratoryResultClinicalElementLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRLaboratoryResultClinicalElementLMCDAFHIR"
      },
      "name" : "Mapping FRLMResultatExamensBiologieElementCliniquePertinent → Profile: FRCDAResultatExamensDeBiologieElementCliniquePertinent\n → FRObservationLaboratoryReportResultsDocument",
      "description" : "Mapping des éléments du modèle métier FRLMResultatExamensBiologieElementCliniquePertinent vers le profil CDA FRCDAResultatExamensDeBiologieElementCliniquePertinent, puis vers le profil FHIR FRObservationLaboratoryReportResultsDocument.",
      "exampleBoolean" : false,
      "groupingId" : "common-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRSectionResultsLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRSectionResultsLMCDAFHIR"
      },
      "name" : "Mapping FRLMResultats → FRCDAResultats → FRCompositionDocument.section:results",
      "description" : "Mapping des éléments du modèle métier FRLMResultats vers la section CDA FRCDAResultats, puis vers la section FHIR FRCompositionDocument.section:results.",
      "exampleBoolean" : false,
      "groupingId" : "section-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRSectionExaminationResultsLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRSectionExaminationResultsLMCDAFHIR"
      },
      "name" : "Mapping FRLMResultatsExamens → FRCDAResultatsExamens → FRCompositionDocument.section:Results",
      "description" : "Mapping des éléments du modèle métier FRLMResultatsExamens vers la section CDA FRCDAResultatsExamens puis vers le profil FHIR FRCompositionDocument.section:Results.",
      "exampleBoolean" : false,
      "groupingId" : "section-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRLaboratoryResultsLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRLaboratoryResultsLMCDAFHIR"
      },
      "name" : "Mapping FRLMResultatsExamensBiologieMedicale → FRCDAResultatExamensDeBiologie → FRObservationLaboratoryReportResultsDocument",
      "description" : "Mapping des éléments du modèle métier FRLMResultatsExamensBiologieMedicale vers le profil CDA FRCDAResultatExamensDeBiologie, puis vers le profil FHIR FRObservationLaboratoryReportResultsDocument.",
      "exampleBoolean" : false,
      "groupingId" : "common-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRSectionUncodedExaminationResultsLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRSectionUncodedExaminationResultsLMCDAFHIR"
      },
      "name" : "Mapping FRLMResultatsExamensNonCode → FRCDAResultatsExamensNonCode → FRCompositionDocument.section:Results",
      "description" : "Mapping des éléments du modèle métier FRLMResultatsExamensNonCode vers la section CDA FRCDAResultatsExamensNonCode puis vers le profil FHIR FRCompositionDocument.section:Results.",
      "exampleBoolean" : false,
      "groupingId" : "section-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRSectionLaboratorySecondIntentionResultsLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRSectionLaboratorySecondIntentionResultsLMCDAFHIR"
      },
      "name" : "Mapping FRLMResultatsLaboratoireBiologieSecondeIntention → FRCDAResultatsDeLaboratoireDeBiologieDeSecondeIntention → FRCompositionDocument.section:sans-sous-sections",
      "description" : "Mapping des éléments du modèle métier FRLMResultatsLaboratoireBiologieSecondeIntention vers la section CDA FRCDAResultatsDeLaboratoireDeBiologieDeSecondeIntention, puis vers le profil FHIR FRCompositionDocument.section:LaboratoryResults.",
      "exampleBoolean" : false,
      "groupingId" : "section-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRImagingSeriesLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRImagingSeriesLMCDAFHIR"
      },
      "name" : "Mapping FRLMSeries → FRCDADICOMSerieImagerie / FRLMSeries → FRImagingStudyDocument",
      "description" : "Mapping des éléments du modèle métier FRLMSeries vers le profil CDA FRCDADICOMSerieImagerie, puis vers le profil FHIR FRImagingStudyDocument.",
      "exampleBoolean" : false
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRServiceRequestLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRServiceRequestLMCDAFHIR"
      },
      "name" : "Mapping FRLMServiceRequest → FRCDADemandeDExamenOuDeSuivi / FRLMServiceRequest → FRServiceRequestDocument",
      "description" : "Mapping des éléments du modèle métier FRLMServiceRequest vers le profil CDA FRCDADemandeDExamenOuDeSuivi, puis vers le profil FHIR FRServiceRequestDocument.",
      "exampleBoolean" : false,
      "groupingId" : "common-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRSectionVitalSignsLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRSectionVitalSignsLMCDAFHIR"
      },
      "name" : "Mapping FRLMSignesVitaux → FRCDASignesVitaux → FRCompositionDocument.section",
      "description" : "Mapping des éléments du modèle métier FRLMSignesVitaux vers la section CDA FRCDASignesVitaux, puis vers le profil FHIR FRCompositionDocument.section:SignesVitaux.",
      "exampleBoolean" : false,
      "groupingId" : "section-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRSpecimenLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRSpecimenLMCDAFHIR"
      },
      "name" : "Mapping FRLMSpecimen → FRCDAPrelevement / FRLMSpecimen → FRSpecimenDocument",
      "description" : "Mapping des éléments du modèle métier FRLMSpecimen vers le profil CDA FRCDAPrelevement, puis vers le profil FHIR FRSpecimenDocument.",
      "exampleBoolean" : false,
      "groupingId" : "common-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRSectionDocumentStatusLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRSectionDocumentStatusLMCDAFHIR"
      },
      "name" : "Mapping FRLMStatutDocument -> FRCDAStatutDuDocument -> FRComposition.section",
      "description" : "Mapping des éléments du modèle métier FRLMStatutDocument vers la section CDA FRCDAStatutDuDocument, puis vers la section FHIR FRCompositionDocument.section:documentStatus.",
      "exampleBoolean" : false,
      "groupingId" : "section-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRSectionFunctionalStatusLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRSectionFunctionalStatusLMCDAFHIR"
      },
      "name" : "Mapping FRLMStatutFonctionnel → FRCDAStatutFonctionnel → FRCompositionDocument.section:FRFunctionalStatus",
      "description" : "Mapping des éléments du modèle métier FRLMStatutFonctionnel vers la section CDA FRCDAStatutFonctionnel, puis vers la section FHIR FRCompositionDocument.section:FRFunctionalStatus.",
      "exampleBoolean" : false,
      "groupingId" : "section-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRSectionMedicationsLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRSectionMedicationsLMCDAFHIR"
      },
      "name" : "Mapping FRLMTraitements → FRCDATraitements → FRCompositionDocument.section:medications",
      "description" : "Mapping des éléments du modèle métier FRLMTraitements vers la section CDA FRCDATraitements, puis vers la section FHIR FRCompositionDocument.section:medications.",
      "exampleBoolean" : false,
      "groupingId" : "section-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRSectionMedicationAdministrationLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRSectionMedicationAdministrationLMCDAFHIR"
      },
      "name" : "Mapping FRLMTraitementsAdministres → FRCDATraitementsAdministres → FRCompositionDocument.section:medicationAdministration",
      "description" : "Mapping des éléments du modèle métier FRLMTraitementsAdministres vers la section CDA FRCDATraitementsAdministres, puis vers la section FHIR FRCompositionDocument.section:medicationAdministration.",
      "exampleBoolean" : false,
      "groupingId" : "section-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRSectionHospitalDischargeMedicationsLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRSectionHospitalDischargeMedicationsLMCDAFHIR"
      },
      "name" : "Mapping FRLMTraitementSortie → FRCDATraitementsALaSortie → FRCompositionDocument.section:hospitalDischargeMedications",
      "description" : "Mapping des éléments du modèle métier FRLMTraitementSortie vers la section CDA FRCDATraitementsALaSortie, puis vers la section FHIR FRCompositionDocument.section:hospitalDischargeMedications.",
      "exampleBoolean" : false,
      "groupingId" : "section-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRSectionImmunizationsLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRSectionImmunizationsLMCDAFHIR"
      },
      "name" : "Mapping FRLMVaccinations → FRCDAVaccinations → FRCompositionDocument.section:immunizations",
      "description" : "Mapping des éléments du modèle métier FRLMVaccinations vers la section CDA FRCDAVaccinations, puis vers la section FHIR FRCompositionDocument.section:immunizations.",
      "exampleBoolean" : false,
      "groupingId" : "section-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-mappingmodelemetierCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/mappingmodelemetierCDAFHIR"
      },
      "name" : "Mapping Métier/CDA/FHIR  : Entête d'un document",
      "description" : "Ce ConceptMap présente trois groupes de mapping :\n - Mapping 1 : entre le modèle métier \\\"EnteteDocument\\\" et l'élément CDA \\\"clinicalDocument\\\"\n - Mapping 2 : entre l'élément CDA \\\"clinicalDocument\\\" et le profil FHIR \\\"FrBundleDocument\\\"\n - Mapping 3 : entre l'élément CDA \\\"clinicalDocument\\\" et le profil FHIR \\\"FrCompositionDocument\\\"",
      "exampleBoolean" : false,
      "groupingId" : "header-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-mappingAuteurCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/mappingAuteurCDAFHIR"
      },
      "name" : "Mapping Métier/CDA/FHIR : \"Auteur\"",
      "description" : "Ce ConceptMap présente deux groupes de mapping : \n - Mapping 1 : entre le modèle métier \\\"Auteur\\\" et l'élément CDA \\\"author\\\"\n - Mapping 2 : entre l'élément CDA \\\"author\\\" et l'élément FHIR \\\"Composition.author\\\"",
      "exampleBoolean" : false,
      "groupingId" : "header-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-mappingConsentementCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/mappingConsentementCDAFHIR"
      },
      "name" : "Mapping Métier/CDA/FHIR : \"Consentement\"",
      "description" : "Ce ConceptMap présente deux groupes de mapping : \n - Mapping 1 : entre le modèle métier \\\"ConsentementAssocie\\\" et l'élément CDA \\\"authorization\\\"\n - Mapping 2 : entre l'élément CDA \\\"authorization\\\" et l'extension FHIR \\\"ConsentExtension\\\"",
      "exampleBoolean" : false,
      "groupingId" : "header-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-mappingDestinatairePrevuCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/mappingDestinatairePrevuCDAFHIR"
      },
      "name" : "Mapping Métier/CDA/FHIR : \"Destinataire prévu\"",
      "description" : "Ce ConceptMap présente deux groupes de mapping : \n - Mapping 1 : entre le modèle métier \\\"destinataire\\\" et l'élément CDA \\\"informationRecipient\\\"\n - Mapping 2 : entre l'élément CDA \\\"informationRecipient\\\" et l'extension FHIR \\\"InformationRecipientExtension\\\"",
      "exampleBoolean" : false,
      "groupingId" : "header-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-mappingDocumentDeReferenceCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/mappingDocumentDeReferenceCDAFHIR"
      },
      "name" : "Mapping Métier/CDA/FHIR : \"DocumentDeReference\"",
      "description" : "Ce ConceptMap présente deux groupes de mapping : \n - Mapping 1 : entre le modèle métier \\\"documentDeReference\\\" et l'élément CDA \\\"relatedDocument\\\"\n - Mapping 2 : entre l'élément CDA \\\"relatedDocument\\\" et l'élément FHIR \\\"Composition.relatesTo\\\"",
      "exampleBoolean" : false,
      "groupingId" : "header-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-mappingEvenementCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/mappingEvenementCDAFHIR"
      },
      "name" : "Mapping Métier/CDA/FHIR : \"Evènement documenté\"",
      "description" : "Ce ConceptMap présente deux groupes de mapping : \n - Mapping 1 :entre le modèle métier \\\"evenement\\\" et l'élément CDA \\\"documentationOf\\\"\n - Mapping 2 : entre l'élément CDA \\\"documentationOf\\\" et l'élément FHIR \\\"Composition.event\\\"",
      "exampleBoolean" : false,
      "groupingId" : "header-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-mappingInformateurCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/mappingInformateurCDAFHIR"
      },
      "name" : "Mapping Métier/CDA/FHIR : \"Informateur\"",
      "description" : "Ce ConceptMap présente deux groupes de mapping : \n - Mapping 1 : entre le modèle métier \\\"informateur\\\" et l'élément CDA \\\"informant\\\"\n - Mapping 2 : entre l'élément CDA \\\"informant\\\" et l'extension FHIR \\\"InformantExtension\\\"",
      "exampleBoolean" : false,
      "groupingId" : "header-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-mappingOperateurSaisieCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/mappingOperateurSaisieCDAFHIR"
      },
      "name" : "Mapping Métier/CDA/FHIR : \"Opérateur de saisie\"",
      "description" : "Ce ConceptMap présente deux groupes de mapping :\n - Mapping 1 : entre le modèle métier \\\"operateurSaisie\\\" et l'élément CDA \\\"dataEnterer\\\"\n - Mapping 2 : entre l'élément CDA \\\"dataEnterer\\\" et l'extension FHIR \\\"DataEntererExtension\\\"",
      "exampleBoolean" : false,
      "groupingId" : "header-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-mappingParticipantCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/mappingParticipantCDAFHIR"
      },
      "name" : "Mapping Métier/CDA/FHIR : \"Participant\"",
      "description" : "Ce ConceptMap présente deux groupes de mapping : \n - Mapping 1 : entre le modèle métier \\\"participant\\\" et l'élément CDA \\\"participant\\\"\n - Mapping 2 : entre l'élément CDA \\\"participant\\\" et l'extension FHIR \\\"ParticipantExtension\\\"",
      "exampleBoolean" : false,
      "groupingId" : "header-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-mappingPatientCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/mappingPatientCDAFHIR"
      },
      "name" : "Mapping Métier/CDA/FHIR : \"Patient/Usager\"",
      "description" : "Ce ConceptMap présente deux groupes de mapping : \n - Mapping 1 : entre le modèle métier \\\"patient\\\" et l'élément CDA \\\"recordTarget\\\"\n - Mapping 2 : entre l'élément CDA \\\"recordTarget\\\" et le profil FHIR \\\"FrPatientDocument\\\"",
      "exampleBoolean" : false,
      "groupingId" : "header-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-mappingPersonneStructureAssignedEntityFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/mappingPersonneStructureAssignedEntityFHIR"
      },
      "name" : "Mapping Métier/CDA/FHIR : \"Personne / Structure (AssignedEntity)\"",
      "description" : "Ce ConceptMap de l'élément PersonneStructure présente deux groupes de mapping : \n - Mapping 1 : entre le modèle métier \\\"PersonneStructure\\\" et l'élément CDA \\\"assignedEntity\\\"\n - Mapping 2 : entre l'élément CDA \\\"assignedEntity\\\" et le profil FHIR \\\"FrPractitionerRoleDocument\\\"",
      "exampleBoolean" : false,
      "groupingId" : "header-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-mappingPersonneStructureAuteurFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/mappingPersonneStructureAuteurFHIR"
      },
      "name" : "Mapping Métier/CDA/FHIR : \"Personne / Structure (Auteur)\"",
      "description" : "Ce ConceptMap de l'élément PersonneStructureAuteur présente deux groupes de mapping : \n - Mapping 1 : entre le modèle métier \\\"PersonneStructureAuteur\\\" et l'élément CDA \\\"assignedAuthor\\\"\n - Mapping 2 : entre l'élément CDA \\\"assignedAuthor\\\" et le profil FHIR \\\"FrPractitionerRoleDocument\\\"",
      "exampleBoolean" : false,
      "groupingId" : "header-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-mappingPersonneStructureRelatedEntityFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/mappingPersonneStructureRelatedEntityFHIR"
      },
      "name" : "Mapping Métier/CDA/FHIR : \"Personne / Structure (RelatedEntity)\"",
      "description" : "Ce ConceptMap de l'élément PersonneStructure présente trois groupes de mapping: \n - Mapping 1 : entre le modèle métier \\\"FRLMPersonneStructure\\\" et l'élément CDA \\\"relatedEntity\\\"\n - Mapping 2 : entre l'élément CDA \\\"relatedEntity\\\" et le profil FHIR \\\"FrRelatedPersonDocument\\\"\n - Mapping 3 : entre l'élément CDA \\\"relatedEntity\\\" et l'élément FHIR \\\"Patient.contact\\\"",
      "exampleBoolean" : false,
      "groupingId" : "header-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-mappingPrescriptionCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/mappingPrescriptionCDAFHIR"
      },
      "name" : "Mapping Métier/CDA/FHIR : \"Prescription\"",
      "description" : "Ce ConceptMap présente deux groupes de mapping : \n - Mapping 1 : entre le modèle métier \\\"prescription\\\" et l'élément CDA \\\"inFulfillmentOf\\\"\n - Mapping 2 : entre l'élément CDA \\\"inFulfillmentOf\\\" et l'extension FHIR \\\"OrderExtension\\\"",
      "exampleBoolean" : false,
      "groupingId" : "header-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-mappingPriseEnchargeCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/mappingPriseEnchargeCDAFHIR"
      },
      "name" : "Mapping Métier/CDA/FHIR : \"Prise en charge\"",
      "description" : "Ce ConceptMap présente deux groupes de mapping : \n - Mapping 1 : entre le modèle métier \\\"prise en charge\\\" et l'élément CDA \\\"componentOf\\\"\n - Mapping 2 : entre l'élément CDA \\\"componentOf\\\" et l'élément FHIR \\\"Composition.encounter(Encounter)\\\"",
      "exampleBoolean" : false,
      "groupingId" : "header-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-mappingResponsableCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/mappingResponsableCDAFHIR"
      },
      "name" : "Mapping Métier/CDA/FHIR : \"Responsable du document\"",
      "description" : "Ce ConceptMap présente deux groupes de mapping : \n - Mapping 1 : entre le modèle métier \\\"responsable\\\" et l'élément CDA \\\"legalAuthenticator\\\"\n - Mapping 2 : entre l'élément CDA \\\"legalAuthenticator\\\" et l'élément FHIR \\\"Composition.attester\\\"",
      "exampleBoolean" : false,
      "groupingId" : "header-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-mappingStructureConservationCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/mappingStructureConservationCDAFHIR"
      },
      "name" : "Mapping Métier/CDA/FHIR : \"Structure chargée de la conservation du document\"",
      "description" : "Ce ConceptMap présente deux groupes de mapping : \n - Mapping 1 : entre le modèle métier \\\"structureConservation\\\" et l'élément CDA \\\"custodian\\\"\n - Mapping 2 : entre l'élément CDA \\\"custodian\\\" et l'élément FHIR \\\"Composition.custodian\\\"",
      "exampleBoolean" : false,
      "groupingId" : "header-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-mappingSystemeFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/mappingSystemeFHIR"
      },
      "name" : "Mapping Métier/CDA/FHIR : \"Système / Structure Auteur\"",
      "description" : "Ce ConceptMap de l'élément SystemeStructureAuteur présente deux groupes de mapping : \n - Mapping 1 : entre le modèle métier \\\"SystemeStructureAuteur\\\" et l'élément CDA \\\"assignedAuthor\\\"\n - Mapping 2 : entre l'élément CDA \\\"assignedAuthor\\\" et le profil FHIR \\\"FrDeviceDocument\\\"",
      "exampleBoolean" : false,
      "groupingId" : "header-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-mappingValidateurCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/mappingValidateurCDAFHIR"
      },
      "name" : "Mapping Métier/CDA/FHIR : \"Validateur\"",
      "description" : "Ce ConceptMap présente deux groupes de mapping : \n - Mapping 1 : entre le modèle métier \\\"validateur\\\" et l'élément CDA \\\"authenticator\\\"\n - Mapping 2 : entre l'élément CDA \\\"authenticator\\\" et l'élément FHIR \\\"Composition.attester\\\"",
      "exampleBoolean" : false,
      "groupingId" : "header-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRSectionImagingActLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRSectionImagingActLMCDAFHIR"
      },
      "name" : "Mapping Métier/CDA/FHIR : Acte d'imagerie",
      "description" : "Mapping des éléments du modèle métier FRLMActeImagerie vers la section CDA FRCDADICOMActeImagerie, puis vers le profil FHIR FRCompositionDocument.section:ImagingStudy.",
      "exampleBoolean" : false,
      "groupingId" : "section-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRSectionAllergyIntoleranceLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRSectionAllergyIntoleranceLMCDAFHIR"
      },
      "name" : "Mapping Métier/CDA/FHIR : Allergies et intolérances",
      "description" : "Mapping des éléments du modèle métier FRLMAllergiesEtHypersensibilites vers la section CDA FRCDAAllergiesEtHypersensibilites, puis vers le profil FHIR FRCompositionDocument.section:AllergyIntolerance.",
      "exampleBoolean" : false,
      "groupingId" : "section-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRSectionFamilyHistoryLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRSectionFamilyHistoryLMCDAFHIR"
      },
      "name" : "Mapping Métier/CDA/FHIR : Antécédents familiaux",
      "description" : "Mapping des éléments du modèle métier FRLMAntecedentsFamiliaux vers la section CDA FRCDAAntecedentsFamiliaux, puis vers le profil FHIR FRCompositionDocument.section:FamilyHistory.",
      "exampleBoolean" : false,
      "groupingId" : "section-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRSectionMedicalHistoryLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRSectionMedicalHistoryLMCDAFHIR"
      },
      "name" : "Mapping Métier/CDA/FHIR : Antécédents médicaux",
      "description" : "Mapping des éléments du modèle métier FRLMAntecedentsMedicaux vers la section CDA FRCDAAntecedentsMedicaux, puis vers le profil FHIR FRCompositionDocument.section:MedicalHistory.",
      "exampleBoolean" : false,
      "groupingId" : "section-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRSectionBarCodesLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRSectionBarCodesLMCDAFHIR"
      },
      "name" : "Mapping Métier/CDA/FHIR : Codes-barres",
      "description" : "Mapping des éléments du modèle métier FRLMCodesAbarres vers la section CDA FRCDACodeABarres, puis vers la section FHIR FRCompositionDocument.section:barCodes.",
      "exampleBoolean" : false,
      "groupingId" : "section-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRSectionNoteLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRSectionNoteLMCDAFHIR"
      },
      "name" : "Mapping Métier/CDA/FHIR : Commentaire ER",
      "description" : "Mapping des éléments du modèle métier FRLMCommentaireNonCode vers la section CDA FRCDACommentaireNonCode, puis vers le profil FHIR FRCompositionDocument.section:note.",
      "exampleBoolean" : false,
      "groupingId" : "section-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "ConceptMap"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "ConceptMap-FRSectionImagingResultsLMCDAFHIR.html"
      }],
      "reference" : {
        "reference" : "ConceptMap/FRSectionImagingResultsLMCDAFHIR"
      },
      "name" : "Mapping Métier/CDA/FHIR : Résultats d'imagerie",
      "description" : "Mapping des éléments du modèle métier FRLMResultatsExamenImagerie vers la section CDA FRCDADICOMResultats puis vers le profil FHIR FRCompositionDocument.section:Findings.",
      "exampleBoolean" : false,
      "groupingId" : "section-mappings"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-adverse-drug-reaction.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-adverse-drug-reaction"
      },
      "name" : "Modèle logique métier - FR LM Adverse Drug Reaction",
      "description" : "Effet indésirable médicamenteux",
      "exampleBoolean" : false,
      "groupingId" : "common-models"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-batterie-examens-biologie-medicale.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-batterie-examens-biologie-medicale"
      },
      "name" : "Modèle logique métier - FR LM Batterie d'examens de biologie médicale",
      "description" : "Entrée Batterie d'examens de biologie médicale",
      "exampleBoolean" : false,
      "groupingId" : "common-models"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-isolat-microbiologique.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-isolat-microbiologique"
      },
      "name" : "Modèle logique métier - FR LM Isolat microbiologique",
      "description" : "Isolat microbiologique",
      "exampleBoolean" : false,
      "groupingId" : "common-models"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-laboratoire-executant.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-laboratoire-executant"
      },
      "name" : "Modèle logique métier - FR LM Laboratoire exécutant",
      "description" : "Laboratoire exécutant",
      "exampleBoolean" : false,
      "groupingId" : "common-models"
    },
    {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
        "valueString" : "StructureDefinition:logical"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/implementationguide-page",
        "valueUri" : "StructureDefinition-fr-lm-resultat-examens-biologie-element-clinique-pertinent.html"
      }],
      "reference" : {
        "reference" : "StructureDefinition/fr-lm-resultat-examens-biologie-element-clinique-pertinent"
      },
      "name" : "Modèle logique métier - FR LM Résultat d'examens de biologie / élement clinique pertinent",
      "description" : "Résultat d'examens de biologie / élement clinique pertinent",
      "exampleBoolean" : false,
      "groupingId" : "common-models"
    }],
    "page" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
        "valueUrl" : "toc.html"
      }],
      "nameUrl" : "toc.html",
      "title" : "Table of Contents",
      "generation" : "html",
      "page" : [{
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "index.html"
        }],
        "nameUrl" : "index.html",
        "title" : "Accueil",
        "generation" : "markdown"
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "structureGenerale.html"
        }],
        "nameUrl" : "structureGenerale.html",
        "title" : "Structure générale document",
        "generation" : "markdown",
        "page" : [{
          "extension" : [{
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
            "valueUrl" : "introduction.html"
          }],
          "nameUrl" : "introduction.html",
          "title" : "Introduction",
          "generation" : "markdown"
        },
        {
          "extension" : [{
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
            "valueUrl" : "exigencesSpecifiques.html"
          }],
          "nameUrl" : "exigencesSpecifiques.html",
          "title" : "Exigences spécifiques",
          "generation" : "markdown"
        },
        {
          "extension" : [{
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
            "valueUrl" : "mappingCDA-FHIR-struc-gen.html"
          }],
          "nameUrl" : "mappingCDA-FHIR-struc-gen.html",
          "title" : "Mapping CDA / FHIR",
          "generation" : "markdown"
        }]
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "enteteDocument.html"
        }],
        "nameUrl" : "enteteDocument.html",
        "title" : "Entête document",
        "generation" : "markdown",
        "page" : [{
          "extension" : [{
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
            "valueUrl" : "mappingCDA-FHIR-entete.html"
          }],
          "nameUrl" : "mappingCDA-FHIR-entete.html",
          "title" : "Mapping Métier/CDA/FHIR",
          "generation" : "markdown"
        }]
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "corpsDocument.html"
        }],
        "nameUrl" : "corpsDocument.html",
        "title" : "Corps d'un document",
        "generation" : "markdown",
        "page" : [{
          "extension" : [{
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
            "valueUrl" : "mappingCDA-FHIR-corps.html"
          }],
          "nameUrl" : "mappingCDA-FHIR-corps.html",
          "title" : "Mapping Métier/CDA/FHIR",
          "generation" : "markdown"
        }]
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "autres_ressources.html"
        }],
        "nameUrl" : "autres_ressources.html",
        "title" : "Autres Ressources",
        "generation" : "markdown",
        "page" : [{
          "extension" : [{
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
            "valueUrl" : "securite.html"
          }],
          "nameUrl" : "securite.html",
          "title" : "Sécurité",
          "generation" : "markdown"
        },
        {
          "extension" : [{
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
            "valueUrl" : "downloads.html"
          }],
          "nameUrl" : "downloads.html",
          "title" : "Téléchargements et usages",
          "generation" : "markdown"
        }]
      },
      {
        "extension" : [{
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "translationinfo.html"
        }],
        "nameUrl" : "translationinfo.html",
        "title" : "Informations sur la traduction",
        "generation" : "markdown"
      }]
    },
    "parameter" : [{
      "code" : "path-resource",
      "value" : "input/capabilities"
    },
    {
      "code" : "path-resource",
      "value" : "input/examples"
    },
    {
      "code" : "path-resource",
      "value" : "input/extensions"
    },
    {
      "code" : "path-resource",
      "value" : "input/models"
    },
    {
      "code" : "path-resource",
      "value" : "input/operations"
    },
    {
      "code" : "path-resource",
      "value" : "input/profiles"
    },
    {
      "code" : "path-resource",
      "value" : "input/resources"
    },
    {
      "code" : "path-resource",
      "value" : "input/vocabulary"
    },
    {
      "code" : "path-resource",
      "value" : "input/maps"
    },
    {
      "code" : "path-resource",
      "value" : "input/testing"
    },
    {
      "code" : "path-resource",
      "value" : "input/history"
    },
    {
      "code" : "path-resource",
      "value" : "fsh-generated/resources"
    },
    {
      "code" : "path-pages",
      "value" : "template/config"
    },
    {
      "code" : "path-pages",
      "value" : "input/assets"
    },
    {
      "code" : "path-pages",
      "value" : "input/images"
    },
    {
      "code" : "path-tx-cache",
      "value" : "input-cache/txcache"
    }]
  }
}

```
